"""Fixed Core capability calls for the AssemblyAI voice transport."""
import asyncio
import json
from uuid import uuid4
from websockets.asyncio.client import connect
from .x6_client import X6Unavailable

CORE_TOOLS = [{
    'type': 'function', 'name': 'get_core_system_status', 'timeout_seconds': 55,
    'description': 'When asked how JARVIS is running or to check system health, execute the real Core system capability. Checks local OTA, MQTT, WebSocket and memory only. Not a GPU or remote node health check. Report returned findings only.',
    'parameters': {'type': 'object', 'properties': {}, 'additionalProperties': False},
}, {
    'type': 'function', 'name': 'get_core_vision_overview', 'timeout_seconds': 135,
    'description': 'When the user explicitly asks for visão geral, what you see, or an overview of the house/cameras, consult the existing Core vision capability and configured cameras. Do not substitute system health, capability listing or a photo from the voice device. Briefly say you are checking, then report actual returned observations and failures without inventing details.',
    'parameters': {'type': 'object', 'properties': {}, 'additionalProperties': False},
}, {
    'type': 'function', 'name': 'recall_core_vision', 'timeout_seconds': 15,
    'description': 'For follow-up questions about the previous vision overview, such as e na garagem, onde você viu isso, or what was in the office, retrieve the last Core vision record for this device. Does not access cameras again. Use this even after reconnecting. Say na última consulta and report missing observations. If the user explicitly requests a new/current check or veja novamente, use get_core_vision_overview instead.',
    'parameters': {'type': 'object', 'properties': {}, 'additionalProperties': False},
}, {
    'type': 'function', 'name': 'get_core_camera_view', 'timeout_seconds': 135,
    'description': 'Consult ONLY the requested camera now. Use for somente a garagem, verifique o escritório or other explicit single-location requests. garage=garagem, office=escritório, laboratory=laboratório, corridor=corredor lateral. Never substitute a full overview. For the previous observation use recall_core_vision.',
    'parameters': {'type': 'object', 'properties': {'location': {'type': 'string', 'enum': ['garage','office','laboratory','corridor']}}, 'required': ['location'], 'additionalProperties': False},
}]

CORE_TOOLS.append({
    'type':'function','name':'run_core_amd_demo','timeout_seconds':140,
    'description':'Only on an explicit user request to test or demonstrate AMD/MI300X, execute a fixed public case through the Core X6 runtime. A generic AMD test request always means smoke; do not ask which test. smoke=arithmetic connectivity test; summary=short English project presentation; analysis=English comparison of 1 versus 8 GPU deployments. No user audio, personal memory or arbitrary document is sent to AMD. Report returned evidence only; no automatic retries.',
    'parameters':{'type':'object','properties':{'case':{'type':'string','enum':['smoke','summary','analysis']}},'required':['case'],'additionalProperties':False},
})

CORE_TOOLS.extend([
    {'type':'function','name':'get_forge_asset_status','timeout_seconds':20,
     'description':'Read simulated pump P-204 status from fresh local Core telemetry. Use for check pump P-204 or verifique a bomba P-204. NEVER calls AMD. Report only returned response and availability.',
     'parameters':{'type':'object','properties':{'asset_id':{'type':'string','enum':['P-204']}},'required':['asset_id'],'additionalProperties':False}},
    {'type':'function','name':'analyze_forge_asset','timeout_seconds':140,
     'description':'Only on an explicit request to analyze pump P-204/FORGE, request governed AMD reasoning through the existing Core X6 contract. Status checks use get_forge_asset_status. No automatic retries. Historical results remain historical; no physical actuation.',
     'parameters':{'type':'object','properties':{'asset_id':{'type':'string','enum':['P-204']}},'required':['asset_id'],'additionalProperties':False}},
])

class CoreCapabilityClient:
    def __init__(self, token, device_scope=None):
        self.token = token
        self.device_scope = device_scope

    async def forge_asset(self, asset_id, *, analyze=False, language='pt-BR'):
        if asset_id!='P-204' or type(analyze) is not bool or language not in ('pt-BR','en'):
            raise ValueError('invalid FORGE request')
        operation='forge_check_asset' if analyze else 'forge_asset_status'
        request_id=str(uuid4())
        try:
            async with connect('ws://127.0.0.1:8765/voice-capability',
                    additional_headers={'Authorization':'Bearer '+self.token},proxy=None,
                    open_timeout=3,close_timeout=2,max_size=32768) as socket:
                await socket.send(json.dumps({'operation':operation,'request_id':request_id,'asset_id':asset_id,'language':language}))
                result=json.loads(await asyncio.wait_for(socket.recv(),130 if analyze else 15))
                if (not isinstance(result,dict) or result.get('request_id')!=request_id
                    or result.get('operation')!=operation or result.get('schema_version')!='forge.result.v1'
                    or result.get('asset_id')!=asset_id or result.get('simulated') is not True
                    or result.get('language')!=language or type(result.get('ok')) is not bool
                    or not isinstance(result.get('response'),str) or not 0<len(result['response'])<=4000):
                    raise ValueError('uncorrelated FORGE result')
                gate=result.get('governance') or {}
                if gate.get('physical_actuation_authorized') is not False or gate.get('physical_actuation_performed') is not False:
                    raise ValueError('invalid FORGE gate')
                if not analyze and result.get('executed_now') is not False:
                    raise ValueError('unexpected compute for status')
                # A correlated block is a real result to speak, never a memorized fallback.
                return result
        except Exception as exc:
            raise X6Unavailable('FORGE_OPERATION_NOT_CONFIRMED') from exc

    async def amd_demo(self, case):
        if not isinstance(case, str) or case not in ('smoke','summary','analysis'):
            raise ValueError('invalid AMD demo case')
        return await self._request('amd_demo_' + case, 130)

    async def system_status(self):
        return await self._request('system_status', 48)

    async def vision_overview(self):
        return await self._request('vision_overview', 125)

    async def camera_view(self, location):
        if not isinstance(location, str) or location not in ('garage', 'office', 'laboratory', 'corridor'):
            raise ValueError('invalid camera')
        return await self._request('vision_' + location, 125)

    async def recall_vision(self):
        return await self._request('vision_recall', 10)

    async def _request(self, operation, timeout):
        request_id = uuid4().hex
        try:
            async with connect('ws://127.0.0.1:8765/voice-capability',
                    additional_headers={'Authorization': 'Bearer ' + self.token},
                    proxy=None, open_timeout=3, close_timeout=2, max_size=32768) as socket:
                payload = {'operation': operation, 'request_id': request_id}
                if self.device_scope:
                    payload['device_scope'] = self.device_scope
                await socket.send(json.dumps(payload))
                result = json.loads(await asyncio.wait_for(socket.recv(), timeout))
                if (not isinstance(result, dict) or result.get('ok') is not True
                    or result.get('request_id') != request_id or result.get('operation') != operation
                    or not isinstance(result.get('response'), str) or not result['response']
                    or len(result['response']) > 4000):
                    raise ValueError('unconfirmed result')
                return result
        except Exception as exc:
            raise X6Unavailable('CORE_OPERATION_NOT_CONFIRMED') from exc
