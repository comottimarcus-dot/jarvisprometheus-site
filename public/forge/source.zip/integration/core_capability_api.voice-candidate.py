"""Authenticated voice entry into the existing Core cognitive cycle."""
import asyncio
import hmac
import json
import os
import re
from datetime import datetime, timezone
from cognition.timeline.capability_trace import execution_summary, identifier
from vision.voice_targets import TARGETS

async def dispatch(cognitive, data):
    if isinstance(data, dict) and data.get('operation') in ('forge_check_asset','forge_asset_status'):
        from voice.forge_adapter import dispatch_forge
        return await dispatch_forge(cognitive, data)
    if not isinstance(data, dict) or set(data) not in ({'operation', 'request_id'}, {'operation', 'request_id', 'device_scope'}):
        raise ValueError('invalid request')
    request_id = data['request_id']
    if not isinstance(request_id, str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,64}', request_id):
        raise ValueError('invalid request id')
    device_scope = data.get('device_scope')
    if device_scope is not None and (not isinstance(device_scope, str) or not re.fullmatch(r'xiaozhi:(?:device:[0-9a-f]{24}|connection:[0-9a-f]{32})', device_scope)):
        raise ValueError('invalid device scope')
    if data['operation'] in ('amd_demo_smoke', 'amd_demo_summary', 'amd_demo_analysis'):
        from voice.amd_demo import run_amd_demo
        return await run_amd_demo(cognitive, data['operation'].removeprefix('amd_demo_'), request_id)
    if data['operation'] == 'vision_recall':
        if not device_scope:
            raise ValueError('device scope required')
        return await asyncio.to_thread(recall_vision, cognitive.episode_memory, device_scope, request_id)
    operations = {
        'system_status': ('Status do sistema', 'system', 'local_core_service_health',
            'Report only the checks returned. This does not verify GPU or remote node availability.'),
        'vision_overview': ('Visão geral', 'vision', 'configured_camera_overview',
            'Describe only returned observations. Report unavailable cameras and uncertainty. Do not infer identities, GPU or executor when absent. This uses configured Core cameras, not a new photo from the voice device.'),
    }
    for target, (camera, label) in TARGETS.items():
        operations['vision_' + target] = (f'Visão da câmera {camera}', 'vision', 'single_camera:' + camera,
            'Consulta somente de ' + label + '. Informe apenas as observações retornadas; se houver falha, diga que a câmera está indisponível. Não consulte outros locais automaticamente.')
    operation = data['operation']
    if not isinstance(operation, str) or operation not in operations:
        raise ValueError('unsupported operation')
    text, capability, scope, instruction = operations[operation]
    result = await cognitive.think(
        raw_user_text=text, normalized_text=text,
        source='xiaozhi', session='assemblyai-capability', input_language='pt-BR',
        conversation_scope='assemblyai-operation:' + request_id,
        voice_operation_id=request_id, voice_device_scope=device_scope,
        voice_core_operation=operation,
    )
    episode = result.episode
    traces = execution_summary(result.execution, episode.results)
    confirmed = any(row.get('capability') == capability and row.get('success') is True for row in traces)
    return {'ok': confirmed, 'request_id': request_id,
            'operation': operation,
            'response': str(result.response)[:4000] if confirmed else '',
            'thought_id': identifier(episode.metadata.get('thought_id')),
            'executions': traces,
            'scope': scope, 'instruction': instruction, 'executed_now': True,
            'observed_at': episode.timestamp if hasattr(episode, 'timestamp') else None}

def recall_vision(memory, device_scope, request_id):
    """Return the latest scoped vision record, never capture or execute again."""
    now = datetime.now(timezone.utc)
    for episode in memory.recent(limit=100):
        metadata = episode.get('metadata') or {}
        if metadata.get('voice_device_scope') != device_scope or metadata.get('voice_core_operation') not in ('vision_overview', *('vision_' + target for target in TARGETS)):
            continue
        try:
            observed = datetime.fromisoformat(episode['timestamp'])
            if observed.tzinfo is None:
                observed = observed.astimezone()
            age = (now - observed).total_seconds()
        except (ValueError, KeyError, TypeError):
            break
        traces = execution_summary({}, episode.get('results') or [])
        confirmed = any(row.get('capability') == 'vision' and row.get('success') is True for row in traces)
        # Do not silently fall back to an older success after a more recent failure.
        if not 0 <= age <= 1800 or not confirmed:
            break
        return {'ok': True, 'request_id': request_id, 'operation': 'vision_recall',
                'response': str(episode.get('response_text') or '')[:4000],
                'observed_at': observed.isoformat(), 'age_seconds': round(age),
                'thought_id': identifier(metadata.get('thought_id')),
                'executions': traces, 'executed_now': False,
                'scope': 'previous_configured_camera_overview',
                'original_operation': metadata.get('voice_core_operation'),
                'instruction': 'Responda em português brasileiro salvo pedido explícito de outro idioma. Diga "na última consulta". Use apenas as observações registradas para o local perguntado. Se o local não aparecer ou houve erro, diga que não há observação disponível. Não invente identidade, localização, GPU ou executor. Nenhuma câmera foi consultada agora.'}
    return {'ok': True, 'request_id': request_id, 'operation': 'vision_recall',
            'response': 'Não há uma visão anterior válida deste aparelho nos últimos 30 minutos.',
            'scope': 'previous_configured_camera_overview', 'available': False,
            'executed_now': False, 'executions': [],
            'instruction': 'Informe a ausência de observação anterior. Não invente uma resposta nem execute nova consulta automaticamente; pergunte se o usuário quer uma nova visão geral.'}

async def handle_capability_socket(socket, cognitive):
    token = os.environ.get('JARVIS_VOICE_MEMORY_TOKEN', '')
    peer = socket.remote_address
    supplied = socket.request.headers.get('Authorization', '')
    if not peer or peer[0] != '127.0.0.1' or not token or not hmac.compare_digest(supplied, 'Bearer ' + token):
        await socket.close(1008, 'unauthorized')
        return
    try:
        raw = await asyncio.wait_for(socket.recv(), 3)
        if not isinstance(raw, str) or len(raw.encode()) > 4096:
            raise ValueError('invalid request')
        data = json.loads(raw)
        timeout = 120 if isinstance(data, dict) and isinstance(data.get('operation'), str) and data['operation'].startswith('vision_') and data['operation'] != 'vision_recall' else 45
        if isinstance(data, dict) and data.get('operation') in ('amd_demo_smoke','amd_demo_summary','amd_demo_analysis','forge_check_asset'):
            timeout = 125
        result = await asyncio.wait_for(dispatch(cognitive, data), timeout)
        await socket.send(json.dumps(result, ensure_ascii=False))
    except Exception:
        try:
            await socket.send('{"ok":false,"error":"core_operation_unavailable"}')
        except Exception:
            pass
    finally:
        await socket.close()
