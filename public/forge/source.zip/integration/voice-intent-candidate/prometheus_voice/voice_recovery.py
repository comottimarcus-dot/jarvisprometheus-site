"""Bounded transport recovery; never replay microphone input or tool requests."""
import asyncio
import json
import logging
from websockets.exceptions import ConnectionClosed, InvalidHandshake
from .core_memory import MemoryUnavailable

logger = logging.getLogger(__name__)
RETRY_DELAYS = (1, 2)


class VoiceServiceUnavailable(RuntimeError):
    pass


class PresentationVoiceSwitch(Exception):
    def __init__(self, enabled, result_text=None, request_text=None):
        self.enabled = enabled
        self.result_text = result_text
        self.request_text = request_text


class RecoveringDevice:
    def __init__(self, device, hello):
        self.device, self.hello = device, hello
        self.request = device.request
        self.messages = asyncio.Queue(maxsize=256)
        self.disconnected = asyncio.Event()
        self.accepting = True
        self.recovering = False
        self.presentation_mode = False
        self.hello_sent = False
        self.session_id = None

    async def recv(self):
        return self.hello

    async def send(self, raw):
        if isinstance(raw, str):
            event = json.loads(raw)
            if event.get('type') == 'hello':
                if self.hello_sent:
                    return
                self.hello_sent = True
                self.session_id = event.get('session_id')
            # The hardware keeps its original session across cloud reconnects.
            if 'session_id' in event and self.session_id:
                event['session_id'] = self.session_id
                raw = json.dumps(event, separators=(',', ':'))
        await self.device.send(raw)

    async def close(self, code=1000, reason=''):
        self.disconnected.set()
        await self.device.close(code, reason)

    def discard_input(self):
        self.accepting = False
        while not self.messages.empty():
            self.messages.get_nowait()

    async def ready(self):
        if self.recovering:
            self.discard_input()
            await self.notice('Reconectado', 'Memória carregada. Pode falar novamente.')
        self.accepting = True

    async def notice(self, status, message):
        await self.send(json.dumps({'type': 'alert', 'status': status,
                                    'message': message, 'emotion': 'neutral'}))

    async def pump(self):
        try:
            async for message in self.device:
                if self.accepting:
                    if self.messages.full():
                        # Do not send a fragmented/old utterance after an overload.
                        raise VoiceServiceUnavailable('device input overflow')
                    self.messages.put_nowait(message)
        finally:
            self.disconnected.set()
            self.discard_input()
            self.messages.put_nowait(None)

    async def __aiter__(self):
        while not self.disconnected.is_set():
            message = await self.messages.get()
            if message is None:
                return
            yield message


async def recover_voice(device, settings, session):
    expected = f'Bearer {settings.xiaozhi_token}' if settings.xiaozhi_token else ''
    if not expected or device.request.headers.get('Authorization', '') != expected:
        await device.close(1008, 'unauthorized')
        return
    try:
        hello = await asyncio.wait_for(device.recv(), 10)
        data = json.loads(hello)
        if not isinstance(data, dict) or data.get('type') != 'hello' or data.get('version') != 2:
            raise ValueError('invalid hello')
    except (ValueError, TypeError, asyncio.TimeoutError):
        await device.close(1002, 'invalid protocol')
        return
    except ConnectionClosed:
        return
    relay = RecoveringDevice(device, hello)
    pump = asyncio.create_task(relay.pump())
    try:
        attempt = 0
        while attempt <= len(RETRY_DELAYS):
            if relay.disconnected.is_set():
                return
            try:
                await session(relay, settings)
                return
            except PresentationVoiceSwitch as change:
                relay.discard_input()
                if not change.enabled:relay.forge_voice_trace=None
                relay.presentation_mode = change.enabled
                relay.english_result = change.result_text
                relay.english_request = change.request_text
                relay.recovering = False
                logger.info('Presentation voice mode: %s', 'English' if change.enabled else 'default')
                continue
            except (VoiceServiceUnavailable, MemoryUnavailable, ConnectionClosed,
                    OSError, InvalidHandshake, asyncio.TimeoutError) as exc:
                relay.discard_input()
                relay.presentation_mode = False  # Never replay a presentation after failure.
                relay.forge_voice_trace=None
                relay.forge_context=None
                relay.english_result = None
                relay.english_request = None
                if relay.disconnected.is_set():
                    return
                # Logs deliberately contain neither transcripts nor exception payloads.
                logger.warning('Voice recovery: attempt=%d category=%s', attempt + 1, type(exc).__name__)
                await relay.send(json.dumps({'type': 'tts', 'state': 'stop', 'interrupted': True}))
                exhausted = attempt == len(RETRY_DELAYS)
                message = ('Serviço indisponível. Tente novamente em instantes.' if exhausted else
                           'Conexão interrompida. Reconectando; aguarde para falar.')
                if isinstance(exc, MemoryUnavailable):
                    message = 'Memória indisponível. Aguardando o Core para retomar.'
                await relay.notice('Indisponível' if exhausted else 'Reconectando', message)
                if exhausted:
                    await relay.close(1013, 'voice_service_unavailable')
                    return
                relay.recovering = True
                try:
                    await asyncio.wait_for(relay.disconnected.wait(), RETRY_DELAYS[attempt])
                    return
                except asyncio.TimeoutError:
                    attempt += 1
    finally:
        pump.cancel()
        await asyncio.gather(pump, return_exceptions=True)
