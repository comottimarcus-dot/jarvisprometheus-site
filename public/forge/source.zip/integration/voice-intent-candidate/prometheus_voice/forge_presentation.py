"""Prepared English FORGE introduction; never an AMD execution."""
import re,unicodedata

SCRIPT="""Hello, judges. Welcome to PROMETHEUS FORGE. I am its voice interface.

FORGE connects physical edge telemetry, spoken requests and governed AI execution for an industrial demonstration.

An ESP32-C3 with a display represents pump P-204. It publishes explicitly simulated temperature, vibration, pressure, motor current, speed and maintenance signals. A physical button changes the scenario between normal, warning and critical.

A status question reads local telemetry in the Core, without GPU inference. An explicit analysis request passes through the existing PROMETHEUS X6 runtime, dispatcher and AMD executor. We have demonstrated warning and critical analysis with Qwen3-32B on one AMD Instinct MI300X running ROCm and vLLM.

The model reviews the supplied signal context. Local rules determine severity, and a separate gate controls what can be presented. When newer samples arrive during inference, the result is labelled historical and current recommendations are blocked. No physical action is authorized or performed.

The existing Xiaozhi voice path preserves conversation memory and interruption. Our evidence includes correlated Core results, audio-submission records and an operator's confirmation of hearing the complete English response. This is distinct from a firmware playback acknowledgement.

This introduction is prepared text. Live industrial analysis is a separate, explicit request. FORGE keeps execution inspectable and decisions with people. Thank you."""

TOOLS=[{'type':'function','name':'get_forge_presentation',
        'description':'Read the prepared English PROMETHEUS FORGE introduction for judges. Use for present FORGE in English or apresente o projeto FORGE em ingles. Reuses the English voice switch; no AMD inference, status check or fabricated live result.',
        'parameters':{'type':'object','properties':{},'additionalProperties':False}}]
INSTRUCTION=' For a FORGE project introduction use get_forge_presentation, not the X6 project introduction or an AMD workload. It is prepared English text, spoken through the existing English voice session. Wait for a new request after finishing.'

def presentation_request(text):
    normalized=''.join(c for c in unicodedata.normalize('NFKD',text.lower()) if not unicodedata.combining(c))
    return bool(re.search(r'\bforge\b',normalized) and re.search(r'\b(apresente|apresentacao|present|presentation|introduce)\b',normalized)
        and not re.search(r'\b(execute|executar|rode|rodar|run|teste|test|benchmark|analyze|analyse|analise)\b',normalized)
        and not re.search(r"\b(?:do not|don't|nao)\s+(?:present|introduce|apresente)\b",normalized))

def presentation_result(arguments):
    if arguments!={}:raise ValueError('presentation takes no arguments')
    return {'ok':True,'kind':'prepared_forge_presentation','language':'en','executed_now':False,
            'gpu_execution':False,'script':SCRIPT,'instruction':'Speak only this prepared English introduction. Do not claim a new AMD execution. Do not start an analysis automatically.'}
