"""Explicit current speech plus short-lived P-204 context; never replay a tool."""
import re,time,unicodedata

def select_forge_intent(text, context=None, *, now=None):
    now=time.monotonic() if now is None else now
    normalized=''.join(c for c in unicodedata.normalize('NFKD',text.lower()) if not unicodedata.combining(c))
    ids=re.findall(r'\b(?:p[ -]?|(?:pump|bomba)\s+)(\d+)\b',normalized)
    if any(value!='204' for value in ids):raise ValueError('unsupported asset')
    if re.search(r"\b(?:do not|don't|nao|never)\s+(?:analyze|analyse|analise|analisar|check|verifique)\b",normalized):raise ValueError('negated request')
    context=context if type(context) is dict else {}
    expires=context.get('expires_at',0)
    active=context.get('asset_id')=='P-204' and type(expires) in (int,float) and 0<=expires-now<=120
    named=bool(re.search(r'\bp[ -]?204\b|(?:pump|bomba)\s+204\b|\bforge\b',normalized))
    pump=bool(re.search(r'\b(pump|bomba)\b',normalized))
    analysis=bool(re.search(r'\b(analise|analisar|analyze|analyse|analysis)\b',normalized))
    status=bool(re.search(r'\b(check|status|state|verifique|verificar|estado)\b',normalized))
    if not (named or (active and pump)) or not (analysis or status):
        raise ValueError('explicit pump status/analysis request required')
    english=bool(re.search(r'\b(em ingles|in english)\b',normalized))
    portuguese=bool(re.search(r'\b(em portugues|in portuguese)\b',normalized))
    language='en' if english else ('pt-BR' if portuguese else context.get('language','pt-BR') if active else 'pt-BR')
    if language not in ('pt-BR','en'):language='pt-BR'
    return {'analyze':analysis,'language':language,'context_used':not named,'asset_id':'P-204'}
