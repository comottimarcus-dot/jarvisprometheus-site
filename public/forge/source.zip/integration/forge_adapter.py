"""FORGE opt-in bridge into the Core-owned execution runtime."""
from pathlib import Path
import sys

FORGE_SRC=Path("/home/marcus/.codex/.chatgpt-projects/g-p-6ab32817e8848191b38aadb18d55edf5/prometheus-forge/src")

async def dispatch_forge(cognitive,data):
    if str(FORGE_SRC) not in sys.path:sys.path.insert(0,str(FORGE_SRC))
    from forge.core_adapter import dispatch_forge as run
    return await run(cognitive,data)
