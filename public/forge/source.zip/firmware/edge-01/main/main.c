#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <sys/time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_system.h"
#include "esp_random.h"
#include "esp_timer.h"
#include "nvs_flash.h"
#include "mqtt_client.h"
#include "cJSON.h"
#include "esp_log.h"
#define SDA_PIN 5
#define SCL_PIN 6
#define BUTTON_PIN 9
#define TOPIC "forge/edge-01/telemetry"
static i2c_master_dev_handle_t oled;
static uint8_t framebuffer[360];
static esp_err_t command(uint8_t c) {
    uint8_t packet[2]={0,c};
    return i2c_master_transmit(oled,packet,2,100);
}
static esp_err_t show(void) {
    for (unsigned page=0;page<5;page++) {
        // 72 visible columns centred in the SSD1306's 128-column RAM.
        if(command(0xb0+page)!=ESP_OK || command(0x0c)!=ESP_OK || command(0x11)!=ESP_OK) return ESP_FAIL;
        uint8_t packet[73]; packet[0]=0x40;
        memcpy(packet+1,framebuffer+page*72,72);
        if(i2c_master_transmit(oled,packet,sizeof packet,100)!=ESP_OK) return ESP_FAIL;
    }
    return ESP_OK;
}
static void pixel(int x,int y) {
    if(x>=0 && x<72 && y>=0 && y<40) framebuffer[(y/8)*72+x]|=1<<(y%8);
}

static bool oled_ok;
static volatile bool online;
static esp_mqtt_client_handle_t client;
static char boot_id[37];
static cJSON *config;
static const char *modes[]={"NORMAL","WARNING","CRITICAL"};
static const char *names[]={"normal","warning","critical"};
static const double values[3][6]={{64,2.1,6,12,1480,0},{79,4.8,5.7,14.5,1470,0},{96,9.2,4.2,18.3,1390,173}};
static const char *keys[]={"temperature_c","vibration_rms_mm_s","pressure_bar","motor_current_a","rpm","maintenance_overdue_hours"};
static void uuid(void){
 uint8_t b[16]; esp_fill_random(b,sizeof b); b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;
 snprintf(boot_id,sizeof boot_id,"%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8],b[9],b[10],b[11],b[12],b[13],b[14],b[15]);
}
static const char *cfg(const char *key){return cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(config,key));}
static bool valid_config(cJSON *c){
 const char *fields[]={"ssid","password","broker","mqtt_password","ca"};
 if(!cJSON_IsObject(c)||cJSON_GetArraySize(c)!=6)return false;
 for(int i=0;i<5;i++)if(!cJSON_IsString(cJSON_GetObjectItemCaseSensitive(c,fields[i])))return false;
 const char *ssid=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(c,"ssid"));
 const char *pass=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(c,"password"));
 const char *broker=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(c,"broker"));
 const char *mq=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(c,"mqtt_password"));
 const char *ca=cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(c,"ca"));
 cJSON *epoch=cJSON_GetObjectItemCaseSensitive(c,"epoch");
 return strlen(ssid)>0&&strlen(ssid)<=32&&strlen(pass)>=8&&strlen(pass)<=63&&strlen(broker)<128&&strncmp(broker,"mqtts://",8)==0&&strlen(mq)>=24&&strlen(mq)<128&&strlen(ca)<2048&&strstr(ca,"BEGIN CERTIFICATE")&&cJSON_IsNumber(epoch)&&epoch->valuedouble>=1700000000&&epoch->valuedouble<=2200000000;
}
static void provision_task(void *arg){
 char line[4096]; size_t n=0; bool overflow=false;
 for(;;){
  int c=fgetc(stdin);
  if(c<0){clearerr(stdin);vTaskDelay(pdMS_TO_TICKS(20));continue;}
  if(c=='\r')continue;
  if(c=='\n'){
   if(!overflow){line[n]=0; cJSON *v=cJSON_Parse(line);
    if(valid_config(v)){
     nvs_handle_t h;
     if(nvs_open("forge",NVS_READWRITE,&h)==ESP_OK){
      esp_err_t e=nvs_set_str(h,"config",line); if(e==ESP_OK)e=nvs_commit(h); nvs_close(h);
      if(e==ESP_OK){puts("FORGE_CONFIG_SAVED");fflush(stdout);vTaskDelay(pdMS_TO_TICKS(300));esp_restart();}
     }
    }
    cJSON_Delete(v);
   }
   puts("FORGE_CONFIG_REJECTED");fflush(stdout);n=0;overflow=false;
  }else if(n<sizeof(line)-1)line[n++]=(char)c;else overflow=true;
 }
}
static void mqtt_event(void *arg,esp_event_base_t base,int32_t id,void *data){
 if(id==MQTT_EVENT_CONNECTED){online=true;esp_mqtt_client_publish(client,"forge/edge-01/status","online",0,1,0);puts("FORGE_MQTT_ONLINE");}
 if(id==MQTT_EVENT_DISCONNECTED){online=false;puts("FORGE_MQTT_OFFLINE");}
}
static void wifi_event(void *arg,esp_event_base_t base,int32_t id,void *data){
 if(base==WIFI_EVENT&&(id==WIFI_EVENT_STA_START||id==WIFI_EVENT_STA_DISCONNECTED)){online=false;esp_wifi_connect();}
 if(base==IP_EVENT&&id==IP_EVENT_STA_GOT_IP&&client==NULL){
  esp_mqtt_client_config_t m={.broker.address.uri=cfg("broker"),.broker.verification.certificate=cfg("ca"),
   .credentials.username="forge-edge-01",.credentials.client_id="forge-edge-01",.credentials.authentication.password=cfg("mqtt_password"),
   .session.keepalive=10,.session.last_will.topic="forge/edge-01/status",.session.last_will.msg="offline",.session.last_will.qos=1,.session.last_will.retain=0};
  client=esp_mqtt_client_init(&m);if(client){esp_mqtt_client_register_event(client,ESP_EVENT_ANY_ID,mqtt_event,NULL);esp_mqtt_client_start(client);}
 }
}
static void network_start(void){
 cJSON *epoch=cJSON_GetObjectItemCaseSensitive(config,"epoch");struct timeval tv={.tv_sec=(time_t)epoch->valuedouble};settimeofday(&tv,NULL);
 ESP_ERROR_CHECK(esp_netif_init()); ESP_ERROR_CHECK(esp_event_loop_create_default()); esp_netif_create_default_wifi_sta();
 wifi_init_config_t wi=WIFI_INIT_CONFIG_DEFAULT();ESP_ERROR_CHECK(esp_wifi_init(&wi));
 ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT,ESP_EVENT_ANY_ID,wifi_event,NULL));
 ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT,IP_EVENT_STA_GOT_IP,wifi_event,NULL));
 wifi_config_t wc={0};memcpy(wc.sta.ssid,cfg("ssid"),strlen(cfg("ssid")));memcpy(wc.sta.password,cfg("password"),strlen(cfg("password")));
 wc.sta.threshold.authmode=WIFI_AUTH_WPA2_PSK;
 ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA,&wc));ESP_ERROR_CHECK(esp_wifi_start());
}
// Compact 3x5 glyphs for the labels used on a 72x40 display.
static uint16_t glyph(char c){switch(c){
case 'A':return 0x5bea;
case 'C':return 0x724f;
case 'E':return 0x72cf;
case 'F':return 0x12cf;
case 'G':return 0x7b4f;
case 'I':return 0x7497;
case 'L':return 0x7249;
case 'M':return 0x5bfd;
case 'N':return 0x5ffd;
case 'O':return 0x7b6f;
case 'P':return 0x13ef;
case 'Q':return 0x4f6f;
case 'R':return 0x5aeb;
case 'S':return 0x79cf;
case 'T':return 0x2497;
case 'U':return 0x7b6d;
case 'W':return 0x5fed;
case 'Y':return 0x24ad;
case '0':return 0x7b6f;
case '1':return 0x749a;
case '2':return 0x73e7;
case '4':return 0x49ed;
case '-':return 0x01c0;
default:return 0;}}
static void text(int x,int y,const char *s){for(;*s;s++,x+=4){uint16_t g=glyph(*s);for(int r=0;r<5;r++)for(int col=0;col<3;col++)if(g&(1<<(r*3+col)))pixel(x+col,y+r);}}
static void screen(int mode){if(!oled_ok)return;memset(framebuffer,0,sizeof framebuffer);text(0,1,"FORGE P-204");text(0,10,"SIM");text(0,19,modes[mode]);text(0,30,online?"MQTT ON":"MQTT OFF");show();}
static void publish(int mode,uint64_t sequence){
 cJSON *o=cJSON_CreateObject();cJSON_AddStringToObject(o,"schema_version","forge.telemetry.v1");cJSON_AddStringToObject(o,"asset_id","P-204");cJSON_AddStringToObject(o,"node_id","forge-edge-01");cJSON_AddStringToObject(o,"boot_id",boot_id);cJSON_AddNumberToObject(o,"sequence",(double)sequence);cJSON_AddNumberToObject(o,"uptime_ms",esp_timer_get_time()/1000);cJSON_AddBoolToObject(o,"simulated",true);cJSON_AddStringToObject(o,"scenario",names[mode]);cJSON *sig=cJSON_AddObjectToObject(o,"signals");for(int i=0;i<6;i++)cJSON_AddNumberToObject(sig,keys[i],values[mode][i]);char *s=cJSON_PrintUnformatted(o);
 if(s){printf("FORGE_TELEMETRY %s\n",s);if(online&&client&&esp_mqtt_client_get_outbox_size(client)<2048)esp_mqtt_client_enqueue(client,TOPIC,s,0,1,0,false);free(s);}cJSON_Delete(o);
}
void app_main(void){
 ESP_ERROR_CHECK(nvs_flash_init()); // Never erase existing flash automatically.
 gpio_config_t b={.pin_bit_mask=1ULL<<BUTTON_PIN,.mode=GPIO_MODE_INPUT,.pull_up_en=GPIO_PULLUP_ENABLE};ESP_ERROR_CHECK(gpio_config(&b));
 i2c_master_bus_config_t bc={.i2c_port=I2C_NUM_0,.sda_io_num=SDA_PIN,.scl_io_num=SCL_PIN,.clk_source=I2C_CLK_SRC_DEFAULT,.glitch_ignore_cnt=7,.flags.enable_internal_pullup=true};i2c_master_bus_handle_t bus;ESP_ERROR_CHECK(i2c_new_master_bus(&bc,&bus));
 for(int a=0x3c;a<=0x3d;a++)if(i2c_master_probe(bus,a,100)==ESP_OK){i2c_device_config_t dc={.dev_addr_length=I2C_ADDR_BIT_LEN_7,.device_address=a,.scl_speed_hz=100000};ESP_ERROR_CHECK(i2c_master_bus_add_device(bus,&dc,&oled));oled_ok=true;break;}
 if(oled_ok){const uint8_t init[]={0xae,0xd5,0x80,0xa8,0x27,0xd3,0,0x40,0x8d,0x14,0x20,0x02,0xa1,0xc8,0xda,0x12,0x81,0x7f,0xd9,0xf1,0xdb,0x40,0xa4,0xa6,0xaf};for(size_t i=0;i<sizeof init;i++)if(command(init[i])!=ESP_OK)oled_ok=false;}
 screen(0);
 uuid();nvs_handle_t h;static char saved[4096];size_t size=sizeof saved;
 if(nvs_open("forge",NVS_READONLY,&h)==ESP_OK){if(nvs_get_str(h,"config",saved,&size)==ESP_OK){config=cJSON_Parse(saved);if(!valid_config(config)){cJSON_Delete(config);config=NULL;}}nvs_close(h);}
 if(xTaskCreate(provision_task,"provision",8192,NULL,3,NULL)!=pdPASS){puts("FORGE_PROVISION_TASK_FAILED");return;}
 if(config)network_start();else puts("FORGE_CONFIG_READY");
 unsigned mode=0,stable=1,candidate=1,ticks=0;int64_t next=0;uint64_t sequence=0;
 for(;;){unsigned raw=gpio_get_level(BUTTON_PIN);if(raw!=candidate){candidate=raw;ticks=0;}else if(ticks<3)ticks++;if(ticks==3&&stable!=candidate){stable=candidate;if(!stable)mode=(mode+1)%3;}
 int64_t now=esp_timer_get_time();if(now>=next){if(!config){puts("FORGE_CONFIG_READY");fflush(stdout);}
 publish(mode,sequence++);next=now+1000000;}screen(mode);vTaskDelay(pdMS_TO_TICKS(20));}
}
