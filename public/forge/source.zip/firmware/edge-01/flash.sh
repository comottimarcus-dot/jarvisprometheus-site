#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
PORT="/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_70:AF:09:3B:DC:64-if00"
test -r "$PORT" && test -w "$PORT"
sha256sum -c firmware.sha256
cd build
/home/marcus/.espressif/python_env/idf5.5_py3.14_env/bin/esptool.py --chip esp32c3 --port "$PORT" --baud 115200 write_flash @flash_args
