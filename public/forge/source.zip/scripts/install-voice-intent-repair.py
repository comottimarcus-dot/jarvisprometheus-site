"""Install reviewed voice-intent delta only; preserve all other source changes."""
from pathlib import Path
from uuid import uuid4
import hashlib,json,os,tempfile
root=Path(__file__).resolve().parents[1]
records=json.loads((root/'integration/voice-intent-baseline.json').read_text())
changes=[]
for row in records:
    target=Path(row['target']);after=(root/row['candidate']).read_bytes()
    compile(after,str(target),'exec')
    if hashlib.sha256(after).hexdigest()!=row['after_sha256']:raise SystemExit('CANDIDATE_CHANGED')
    before=target.read_bytes() if target.exists() else None
    digest=hashlib.sha256(before).hexdigest() if before is not None else None
    if digest==row['after_sha256']:continue
    if digest!=row['before_sha256']:raise SystemExit('SOURCE_CHANGED_SINCE_REVIEW — '+str(target))
    if not os.access(target.parent,os.W_OK):raise SystemExit('TARGET_NOT_WRITABLE')
    changes.append((target,before,after))
if not changes:raise SystemExit('FORGE_VOICE_INTENT_AND_PRESENTATION_ALREADY_INSTALLED')
backup=root/'.runtime'/('voice-intent-'+str(uuid4()));backup.mkdir(mode=0o700)
for i,(target,before,after) in enumerate(changes):
    if before is not None:
        f=backup/f'{i}-{target.name}';f.write_bytes(before);f.chmod(0o600)
def replace(target,content):
    mode=target.stat().st_mode & 0o777 if target.exists() else 0o644
    fd,tmp=tempfile.mkstemp(dir=target.parent,prefix='forge-intent-')
    try:
        with os.fdopen(fd,'wb') as f:f.write(content)
        os.chmod(tmp,mode);os.replace(tmp,target)
    finally:Path(tmp).unlink(missing_ok=True)
written=[]
try:
    for target,before,after in changes:replace(target,after);written.append((target,before))
except Exception:
    for target,before in reversed(written):
        if before is None:target.unlink(missing_ok=True)
        else:replace(target,before)
    raise
print('FORGE_VOICE_INTENT_AND_PRESENTATION_INSTALLED — restart existing Assembly voice service; no inference performed')
