"""Collect only FORGE correlation logs; optional explicit operator listening attestation."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import re
import subprocess
import sys
from uuid import UUID

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from forge.voice_evidence import normalize_voice_log

p=argparse.ArgumentParser()
p.add_argument('--request-id')
p.add_argument('--heard-complete',action='store_true',help='Operator confirms personally hearing the entire returned response')
a=p.parse_args()
if a.heard_complete and not a.request_id:raise SystemExit('REQUEST_ID_REQUIRED_FOR_LISTENING_CONFIRMATION')
if a.request_id:
    try:
        if str(UUID(a.request_id))!=a.request_id:raise ValueError()
    except ValueError:raise SystemExit('INVALID_REQUEST_ID')
proc=subprocess.run(['journalctl','-u','jarvis-assembly-voice.service','--since','20 minutes ago','-n','2000','-o','json','--no-pager'],capture_output=True,text=True,timeout=10)
if proc.returncode:raise SystemExit('VOICE_JOURNAL_UNAVAILABLE')
rows=[]
for line in proc.stdout.splitlines():
    try:d=json.loads(line)
    except ValueError:continue
    message=normalize_voice_log(d.get('MESSAGE',''))
    if message is None:continue
    if a.request_id and ('request_id='+a.request_id) not in message:continue
    rows.append({'journal_timestamp_us':d.get('__REALTIME_TIMESTAMP'),'message':message})
if not rows:raise SystemExit('NO_CORRELATED_FORGE_VOICE_LOGS — no acoustic confirmation recorded')
if a.heard_complete:
    stages={prefix:any(row['message'].startswith(prefix) for row in rows) for prefix in ('FORGE Core result:','FORGE playback started:','FORGE playback submitted completely:')}
    if not all(stages.values()):raise SystemExit('INCOMPLETE_SUBMISSION_TRACE — listening attestation not recorded')
    transcription=input('Transcrição opcional do que ouviu; ENTER registra apenas sua confirmação de escuta completa: ').strip()
    if len(transcription)>4000:raise SystemExit('LISTENED_RESPONSE_TOO_LONG')
    transcription=transcription or None
else:transcription=None
record={'captured_at':datetime.now(timezone.utc).isoformat(),'request_id_filter':a.request_id,'logs':rows,
        'operator_listening_confirmed':a.heard_complete,'operator_reported_response':transcription,
        'response_transcription_available':transcription is not None,'listening_confirmation_source':'explicit_operator_flag' if a.heard_complete else None,
        'firmware_playback_ack_verified':False,'audio_recording_attached':False,
        'limitation':'Journal messages show bridge submission only. Listening is an explicit operator attestation, not an instrumented firmware ACK.'}
root=Path(__file__).resolve().parents[1]
path=root/'evidence'/('FORGE-VOICE-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'evidence':str(path),'records':len(rows),'operator_listening_confirmed':a.heard_complete,'firmware_playback_ack_verified':False,'correlated_logs':rows},ensure_ascii=False,indent=2))
