"""Hash-guarded installation into existing repositories; never restart services here."""
from pathlib import Path
import hashlib,json,os,tempfile
from uuid import uuid4
root=Path(__file__).resolve().parents[1]
records=json.loads((root/'integration/voice-baseline.json').read_text())
changes=[]
for record in records:
    target=Path(record['target']);candidate=root/record['candidate']
    before=target.read_bytes();after=candidate.read_bytes()
    digest=hashlib.sha256(before).hexdigest()
    if hashlib.sha256(after).hexdigest()!=record['after_sha256']:raise SystemExit('CANDIDATE_CHANGED — no files modified')
    compile(after,str(target),'exec')
    if digest==record['after_sha256']:continue
    if digest!=record['before_sha256']:raise SystemExit('SOURCE_CHANGED_SINCE_REVIEW — '+str(target))
    if not os.access(target,os.W_OK) or not os.access(target.parent,os.W_OK):raise SystemExit('TARGET_NOT_WRITABLE')
    changes.append((target,before,after))
if not changes:raise SystemExit('FORGE_VOICE_ADAPTER_ALREADY_INSTALLED')
backup=root/'.runtime'/('voice-install-'+str(uuid4()));backup.mkdir(mode=0o700)
for i,(target,before,after) in enumerate(changes):
    f=backup/f'{i}-{target.name}';f.write_bytes(before);f.chmod(0o600)
manifest=backup/'manifest.json';manifest.write_text(json.dumps([str(t) for t,_,_ in changes]));manifest.chmod(0o600)
def replace(target,content):
    fd,tmp=tempfile.mkstemp(dir=target.parent,prefix='forge-voice-')
    try:
        with os.fdopen(fd,'wb') as f:f.write(content)
        os.chmod(tmp,target.stat().st_mode & 0o777)
        os.replace(tmp,target)
    finally:Path(tmp).unlink(missing_ok=True)
written=[]
try:
    for target,before,after in changes:
        replace(target,after);written.append((target,before))
except Exception:
    for target,before in reversed(written):replace(target,before)
    raise
print('FORGE_VOICE_ADAPTER_INSTALLED — restart existing Core and Assembly voice services; no inference performed')
