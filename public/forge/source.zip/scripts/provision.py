"""Provision only after a live firmware marker; never echo credentials."""
import json
from pathlib import Path
import time
import serial

root=Path(__file__).resolve().parents[1]
path=root/".runtime/provision.json"
if path.stat().st_mode & 0o077:raise SystemExit("PROVISION_FILE_MUST_BE_PRIVATE")
data=json.loads(path.read_text());data["epoch"]=int(time.time())
wire=(json.dumps(data)+"\n").encode()
if len(wire)>4095:raise SystemExit("PROVISION_TOO_LARGE")
port="/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_70:AF:09:3B:DC:64-if00"
s=serial.Serial(port=None,baudrate=115200,timeout=.5,write_timeout=5)
s.dtr=False;s.rts=False;s.port=port
try:
    s.open()
    deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        line=s.readline()
        if b"FORGE_CONFIG_READY" in line or b"FORGE_TELEMETRY " in line:
            print("EDGE_FIRMWARE_READY");break
    else:raise SystemExit("EDGE_FIRMWARE_NOT_READY — capture boot log; configuration was not sent")
    for offset in range(0,len(wire),64):
        chunk=wire[offset:offset+64]
        if s.write(chunk)!=len(chunk):raise SystemExit("PROVISION_WRITE_INCOMPLETE")
        time.sleep(.01)
    s.flush()
    deadline=time.monotonic()+15
    while time.monotonic()<deadline:
        line=s.readline()
        if b"FORGE_CONFIG_SAVED" in line:
            print("PROVISIONING_CONFIRMED");break
        if b"FORGE_CONFIG_REJECTED" in line:raise SystemExit("PROVISIONING_REJECTED")
    else:raise SystemExit("PROVISIONING_NOT_CONFIRMED")
except serial.SerialTimeoutException:
    raise SystemExit("PROVISION_USB_WRITE_TIMEOUT — no successful configuration claimed") from None
finally:
    s.close()
