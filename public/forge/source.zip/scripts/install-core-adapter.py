"""Apply only the reviewed, hash-guarded Core changes; no service restart here."""
from pathlib import Path
import hashlib
import json
import os
import tempfile

root=Path(__file__).resolve().parents[1]
api=Path("/home/marcus/jarvis-core/voice/core_capability_api.py")
loader=api.parent/"forge_adapter.py"
expected=json.loads((root/"integration/baseline.json").read_text())["core_api_sha256"]
candidate=(root/"integration/core_capability_api.candidate.py").read_bytes()
source_loader=(root/"integration/forge_adapter.py").read_bytes()
if api.read_bytes()==candidate and loader.is_file() and loader.read_bytes()==source_loader:
    print("CORE_ADAPTER_ALREADY_INSTALLED");raise SystemExit(0)
if hashlib.sha256(api.read_bytes()).hexdigest()!=expected:
    raise SystemExit("CORE_CHANGED_SINCE_REVIEW — no files modified")
if loader.exists():raise SystemExit("EXISTING_ADAPTER_CONFLICT — no files modified")
compile(candidate,str(api),"exec");compile(source_loader,str(loader),"exec")
# Preserve the exact pre-integration API inside the private project for rollback.
backup=root/".runtime/core-api-before-forge.py"
if backup.exists():raise SystemExit("ROLLBACK_FILE_ALREADY_EXISTS — no files modified")
backup.write_bytes(api.read_bytes());backup.chmod(0o600)
# Preflight same-user write access to both destinations before changing either.
if not os.access(api,os.W_OK) or not os.access(api.parent,os.W_OK):raise SystemExit("CORE_NOT_WRITABLE")
loader.write_bytes(source_loader)
try:
    fd,tmp=tempfile.mkstemp(dir=api.parent,prefix="forge-api-")
    with os.fdopen(fd,"wb") as f:f.write(candidate)
    os.chmod(tmp,api.stat().st_mode & 0o777)
    os.replace(tmp,api)
except Exception:
    loader.unlink(missing_ok=True)
    raise
print("CORE_ADAPTER_INSTALLED — restart Core to activate; compute remains blocked without allocation")
