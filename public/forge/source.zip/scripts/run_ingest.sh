#!/usr/bin/env bash
set -euo pipefail
umask 077
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
test -f .runtime/client.json
openssl x509 -in .runtime/broker.crt -checkend 3600 -noout
if ! systemctl is-active --quiet prometheus-forge-mqtt.service; then
    bash scripts/deploy-broker.sh
fi
EXPECTED="/etc/mosquitto/certs/forge-edge-01/broker.conf"
COMMAND="$(systemctl show prometheus-forge-mqtt.service --property=ExecStart --value)"
[[ "$COMMAND" == *"/usr/sbin/mosquitto"* && "$COMMAND" == *"$EXPECTED"* ]] || { echo "UNEXPECTED_FORGE_SERVICE_CONFIGURATION"; exit 1; }
PYTHONPATH=src /home/marcus/jarvis-core/.venv/bin/python -m forge.mqtt_ingest --config .runtime/client.json
