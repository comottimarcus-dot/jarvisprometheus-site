#!/usr/bin/env bash
set -euo pipefail
umask 077
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
DEST_DIR="/etc/mosquitto/certs/forge-edge-01"
UNIT="prometheus-forge-mqtt.service"
for FILE in broker.conf broker.crt broker.key passwords acl; do test -f ".runtime/$FILE"; done
openssl x509 -in .runtime/broker.crt -checkend 3600 -noout
# Never create a config in conf.d, where the existing JARVIS broker might load it.
python3 - <<'PYCONFIG'
from pathlib import Path
root=Path.cwd()/".runtime"
dest=Path("/etc/mosquitto/certs/forge-edge-01")
lines=(root/"broker.conf").read_text().splitlines()
keys={"password_file":"passwords","acl_file":"acl","certfile":"broker.crt","keyfile":"broker.key"}
result=[]
for line in lines:
    key=line.split(maxsplit=1)[0] if line.strip() else ""
    result.append(key+" "+str(dest/keys[key]) if key in keys else line)
(root/"deployed-broker.conf").write_text("\n".join(result)+"\n")
PYCONFIG
sudo -v
if systemctl is-active --quiet "$UNIT"; then
    echo "FORGE_BROKER_ALREADY_ACTIVE — no files overwritten; stop this dedicated unit before intentional redeployment"
    exit 1
fi
sudo install -d -o root -g mosquitto -m 0750 "$DEST_DIR"
for FILE in broker.crt broker.key passwords acl; do
    sudo install -o root -g mosquitto -m 0640 ".runtime/$FILE" "$DEST_DIR/$FILE"
done
sudo install -o root -g mosquitto -m 0640 .runtime/deployed-broker.conf "$DEST_DIR/broker.conf"
sudo systemd-run --unit=prometheus-forge-mqtt --collect --property=User=mosquitto --property=Group=mosquitto /usr/sbin/mosquitto -c "$DEST_DIR/broker.conf"
sleep 1
if ! systemctl is-active --quiet "$UNIT"; then
    echo "FORGE_BROKER_START_FAILED"
    sudo journalctl -u "$UNIT" -n 30 --no-pager
    exit 1
fi
echo "FORGE_BROKER_ACTIVE — dedicated TLS listener on port18884"
