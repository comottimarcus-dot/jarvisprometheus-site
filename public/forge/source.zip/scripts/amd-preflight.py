"""Read-only readiness: services, deployment inventory and model listing; no completion."""
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
from urllib.request import Request,build_opener,HTTPRedirectHandler,ProxyHandler
from dotenv import dotenv_values

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

for service,user_scope in (('prometheus-amd-tunnel-20261013.service',True),('jarvis-prometheus-core.service',False)):
    command=['systemctl']+(['--user'] if user_scope else [])+['is-active',service]
    p=subprocess.run(command,capture_output=True,text=True)
    if p.returncode or p.stdout.strip()!='active':raise SystemExit('SERVICE_NOT_ACTIVE — '+service)
    print(service+': ACTIVE')
cfg=dotenv_values('/home/marcus/jarvis-core/.env')
origin=cfg.get('JARVIS_MI300X_BASE_URL','').strip().rstrip('/')
if origin!='http://127.0.0.1:18000' or cfg.get('JARVIS_MI300X_MODEL')!='Qwen/Qwen3-32B':
    raise SystemExit('AMD_CONFIG_CHANGED — no request performed')
inv=json.loads(Path('/home/marcus/jarvis-core/memory/mi300x-deployment-inventory.json').read_text())
observed=datetime.fromisoformat(inv['inventory_observed_at'])
if observed.tzinfo is None:raise SystemExit('INVENTORY_TIME_INVALID')
age=(datetime.now(timezone.utc)-observed).total_seconds()
if not 0<=age<=8*3600 or inv.get('endpoint')!=origin or inv.get('model')!=cfg['JARVIS_MI300X_MODEL'] or inv.get('node')!='AMD-608786419-ATL1':
    raise SystemExit('INVENTORY_NOT_CURRENT_OR_MISMATCHED')
headers={}
if cfg.get('JARVIS_MI300X_API_KEY'):headers['Authorization']='Bearer '+cfg['JARVIS_MI300X_API_KEY']
try:
    with build_opener(ProxyHandler({}),NoRedirect()).open(Request(origin+'/v1/models',headers=headers),timeout=5) as response:
        raw=response.read(65537)
        if len(raw)>65536:raise ValueError()
        data=json.loads(raw)
    if not any(row.get('id')==cfg['JARVIS_MI300X_MODEL'] for row in data.get('data',[])):raise ValueError()
except Exception:raise SystemExit('AMD_MODEL_LIST_NOT_CONFIRMED — no completion attempted') from None
print(json.dumps({'status':'AMD_PREFLIGHT_PASS','model':cfg['JARVIS_MI300X_MODEL'],'node':inv['node'],'gpu':inv.get('gpu'),'hardware_evidence':'deployment_inventory','inventory_age_seconds':round(age),'inference_calls':0,'note':'Tunnel expiry does not stop droplet billing; acoustic return remains unverified.'},ensure_ascii=False,indent=2))
