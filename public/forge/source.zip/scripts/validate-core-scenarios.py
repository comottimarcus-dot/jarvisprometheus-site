"""Operator-driven physical scenario evidence; compute allocation must be absent."""
import json
import os
from pathlib import Path
import subprocess
import sys
import socket
import time
from datetime import datetime, timezone

root=Path(__file__).resolve().parents[1]
if (root/'.runtime/compute-allocation.json').exists():
    raise SystemExit('LOCAL_VALIDATION_BLOCKED — compute allocation exists')
def ensure_local_only():
    if (root/'.runtime/compute-allocation.json').exists():
        raise SystemExit('LOCAL_VALIDATION_BLOCKED — compute allocation exists')

def read_result():
    ensure_local_only()
    env=dict(os.environ,PYTHONPATH=str(root/'src'))
    proc=subprocess.run([sys.executable,'-m','forge.query_core'],cwd=root,env=env,
                        stdout=subprocess.PIPE,text=True,timeout=150)
    if proc.returncode:
        raise SystemExit('CORE_QUERY_FAILED — no scenario certified')
    try:return json.loads(proc.stdout)
    except ValueError:raise SystemExit('CORE_RESULT_INVALID — no scenario certified')

print('Aguardando Core na porta 8765 (até 30 segundos)...')
deadline=time.monotonic()+30
while True:
    ensure_local_only()
    try:
        with socket.create_connection(('127.0.0.1',8765),timeout=1):pass
        break
    except OSError:
        if time.monotonic()>=deadline:
            raise SystemExit('CORE_NOT_READY — inspect systemctl status jarvis-prometheus-core.service')
        time.sleep(0.5)
print('Inicializando o assinante FORGE e aguardando telemetria fresca...')
for attempt in range(10):
    warm=read_result()
    if warm.get('reason')=='FORGE_COMPUTE_NOT_AUTHORIZED' and (warm.get('snapshot') or {}).get('availability')=='fresh':
        break
    if not str(warm.get('reason','')).startswith('TELEMETRY_'):
        raise SystemExit('CORE_WARMUP_BLOCKED — '+str(warm.get('reason','UNKNOWN')))
    time.sleep(1)
else:
    snap=warm.get('snapshot') or {}
    raise SystemExit('CORE_TELEMETRY_NOT_READY — '+json.dumps({'reason':warm.get('reason'),'availability':snap.get('availability'),'latest_error':snap.get('latest_error')},ensure_ascii=False))
print('CORE_READY — telemetria fresca; computação bloqueada')
results=[]
for scenario in ('warning','critical','normal'):
    input(f'Coloque a C3 em {scenario.upper()}, aguarde 2 segundos e pressione ENTER: ')
    if (root/'.runtime/compute-allocation.json').exists():
        raise SystemExit('LOCAL_VALIDATION_BLOCKED — compute allocation exists')
    data=read_result()
    try:
        snap=data['snapshot']; gate=data['governance']
        checks={
            'contract':data.get('schema_version')=='forge.result.v1' and data.get('asset_id')=='P-204' and data.get('simulated') is True,
            'fresh':snap.get('availability')=='fresh',
            'severity':snap.get('severity')==scenario,
            'compute_blocked':data.get('reason')=='FORGE_COMPUTE_NOT_AUTHORIZED' and data.get('executed_now') is False,
            'no_calls':snap.get('amd_calls')==0 and snap.get('actuator_calls')==0,
            'no_actuation':gate.get('physical_actuation_authorized') is False and gate.get('physical_actuation_performed') is False,
            'findings':bool(snap.get('findings')) if scenario!='normal' else snap.get('findings')==[],
        }
    except (ValueError,KeyError,TypeError):
        raise SystemExit('CORE_RESULT_INVALID — no scenario certified')
    record={'expected_scenario':scenario,'checks':checks,'result':data}
    results.append(record)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    path=root/'evidence'/f'FORGE-03_{scenario}_{stamp}.json'
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'scenario':scenario,'checks':checks,'evidence':str(path)},ensure_ascii=False,indent=2))
    if not all(checks.values()):
        raise SystemExit('SCENARIO_VALIDATION_FAILED — inspect evidence; do not proceed')
print('FORGE_03_LOCAL_SCENARIOS=PASS — physical AMD reasoning remains pending')
