"""One explicit AMD query after allocation; no retries or auto authorization."""
import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import socket
import time

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from forge.golden import assess_run
p=argparse.ArgumentParser()
p.add_argument('--execute',action='store_true',help='Admit one query using an existing private FORGE allocation')
p.add_argument('--scenario',choices=['normal','warning','critical'],default='warning')
p.add_argument('--language',choices=['pt-BR','en'],default='pt-BR')
a=p.parse_args()
allocation=root/'.runtime/compute-allocation.json'
if not a.execute:
    print('GOLDEN_RUN_PREPARED — no query performed; voice evidence pending')
    print('FORGE_ALLOCATION='+('PRESENT_NOT_VALIDATED' if allocation.exists() else 'MISSING'))
    raise SystemExit(0)
if not allocation.is_file():raise SystemExit('FORGE_COMPUTE_NOT_AUTHORIZED — no query performed')
deadline=time.monotonic()+30
while True:
    try:
        with socket.create_connection(('127.0.0.1',8765),timeout=1):pass
        break
    except OSError:
        if time.monotonic()>=deadline:raise SystemExit('CORE_NOT_READY — no query performed')
        time.sleep(0.5)
input(f'Confirm C3 {a.scenario.upper()}, MQTT ON; ENTER submits one explicit AMD query: ' if a.language=='en' else f'Confirme a C3 em {a.scenario.upper()}, MQTT ON; ENTER admite uma única consulta AMD: ')
proc=subprocess.run([sys.executable,'-m','forge.query_core'],cwd=root,
    env=dict(os.environ,PYTHONPATH=str(root/'src'),FORGE_EXPECTED_SEVERITY=a.scenario,FORGE_LANGUAGE=a.language),stdout=subprocess.PIPE,text=True,timeout=150)
if proc.returncode:raise SystemExit('GOLDEN_QUERY_FAILED — no automatic retry')
try:data=json.loads(proc.stdout)
except ValueError:raise SystemExit('GOLDEN_RESULT_INVALID — no automatic retry')
assessment=assess_run(data,a.scenario)
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
path=root/'evidence'/f'FORGE-05_{a.scenario}_{stamp}.json'
path.write_text(json.dumps({'captured_at':datetime.now(timezone.utc).isoformat(),'assessment':assessment,'result':data},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'assessment':assessment,'result_severity':data.get('severity') or (data.get('snapshot') or {}).get('severity'),'reason':data.get('reason'),'response':data.get('response'),'elapsed_seconds':data.get('elapsed_seconds'),'evidence':str(path)},ensure_ascii=False,indent=2))
if not assessment['backend_evidence_pass']:raise SystemExit('GOLDEN_BACKEND_NOT_CONFIRMED — inspect evidence; no automatic retry')
