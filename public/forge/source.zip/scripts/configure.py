"""Generate private demo TLS/auth config; credentials never enter source/binaries."""
import getpass
import ipaddress
import json
import os
from pathlib import Path
import secrets
import subprocess
import time

root=Path(__file__).resolve().parents[1]
run=root/".runtime"
os.umask(0o077)
run.mkdir(mode=0o700,exist_ok=True)
if any(run.iterdir()):
    raise SystemExit("CONFIG_ALREADY_EXISTS — use existing config; do not silently rotate credentials")
host=str(ipaddress.IPv4Address(input("Envy IPv4 [192.168.1.8]: ").strip() or "192.168.1.8"))
ssid=input("Wi-Fi SSID: ")
password=getpass.getpass("Wi-Fi password (local input only): ")
if not 1<=len(ssid.encode())<=32 or not 8<=len(password.encode())<=63:
    raise SystemExit("INVALID_WIFI_CONFIGURATION")
edge=secrets.token_urlsafe(32);reader=secrets.token_urlsafe(32)
subprocess.run(["openssl","req","-x509","-newkey","ec","-pkeyopt","ec_paramgen_curve:prime256v1",
    "-nodes","-keyout",str(run/"broker.key"),"-out",str(run/"broker.crt"),"-days","7",
    "-subj","/CN="+host,"-addext","subjectAltName=IP:"+host],check=True,capture_output=True)
(run/"passwords").write_text("forge-edge-01:"+edge+"\nforge-ingest-01:"+reader+"\n")
subprocess.run(["mosquitto_passwd","-U",str(run/"passwords")],check=True,capture_output=True)
(run/"acl").write_text("user forge-edge-01\ntopic write forge/edge-01/telemetry\ntopic write forge/edge-01/status\nuser forge-ingest-01\ntopic read forge/edge-01/telemetry\ntopic read forge/edge-01/status\n")
(run/"broker.conf").write_text(f"listener 18884 {host}\nallow_anonymous false\npassword_file {run/'passwords'}\nacl_file {run/'acl'}\ncertfile {run/'broker.crt'}\nkeyfile {run/'broker.key'}\ntls_version tlsv1.2\npersistence false\nmax_packet_size 4096\nmax_queued_messages 4\n")
(run/"client.json").write_text(json.dumps({"host":host,"reader_password":reader,"ca":str(run/"broker.crt")}))
(run/"provision.json").write_text(json.dumps({"ssid":ssid,"password":password,"broker":"mqtts://"+host+":18884","mqtt_password":edge,"ca":(run/"broker.crt").read_text(),"epoch":int(time.time())})+"\n")
print("PRIVATE_TLS_CONFIGURATION_CREATED; certificate valid for seven days")
