"""Record Marcus's Academy authorization, without a request-count quota."""
import argparse
from datetime import datetime,timedelta,timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
from uuid import uuid4
from dotenv import dotenv_values

parser=argparse.ArgumentParser()
parser.add_argument('--renew-used',action='store_true',help='Compatibility flag; a count quota is no longer imposed')
parser.parse_args()
root=Path(__file__).resolve().parents[1]
cfg=dotenv_values('/home/marcus/jarvis-core/.env')
origin=cfg.get('JARVIS_MI300X_BASE_URL','').strip().rstrip('/')
if cfg.get('JARVIS_MI300X_ENABLED')!='1' or not origin or not cfg.get('JARVIS_MI300X_MODEL'):
    raise SystemExit('CORE_AMD_CONFIGURATION_NOT_READY')
path=root/'.runtime/compute-allocation.json'
expiry=datetime.now(timezone.utc)+timedelta(hours=8)
d={'campaign':'academy','purpose':'forge_user_authorized',
   'authorization_id':'FORGE-ACADEMY-'+str(uuid4()),'endpoint_sha256':hashlib.sha256(origin.encode()).hexdigest(),
   'max_requests':None,'expires_at':expiry.isoformat()}
if path.exists():
    previous=json.loads(path.read_text())
    if previous.get('campaign')!='academy' or previous.get('purpose')!='forge_user_authorized' or previous.get('endpoint_sha256')!=d['endpoint_sha256']:
        raise SystemExit('EXISTING_ALLOCATION_SCOPE_MISMATCH — preserved')
    d['authorization_id']=previous['authorization_id']
    history=root/'.runtime/allocation-history';history.mkdir(mode=0o700,exist_ok=True)
    archived=history/('allocation-'+str(uuid4())+'.json')
    with os.fdopen(os.open(archived,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'w') as f:json.dump(previous,f)
fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='allocation-')
try:
    with os.fdopen(fd,'w') as f:json.dump(d,f)
    os.replace(tmp,path)
finally:
    Path(tmp).unlink(missing_ok=True)
print('FORGE_ACADEMY_AUTHORIZED — no request-count quota; authorization valid for eight hours; no inference performed')
print('Credit source: Academy; project: FORGE ACT III; request ledger and existing endpoint preserved')
