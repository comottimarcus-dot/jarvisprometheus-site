#!/usr/bin/env bash
set -euo pipefail
umask 077
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
for TOOL in python3 openssl mosquitto mosquitto_passwd; do command -v "$TOOL" >/dev/null; done
/home/marcus/jarvis-core/.venv/bin/python -c 'import paho.mqtt.client'
/home/marcus/.espressif/python_env/idf5.5_py3.14_env/bin/python -c 'import serial'
if [ ! -f .runtime/client.json ]; then python3 scripts/configure.py; fi
bash firmware/edge-01/flash.sh
sleep 2
/home/marcus/.espressif/python_env/idf5.5_py3.14_env/bin/python scripts/provision.py
bash scripts/run_ingest.sh
