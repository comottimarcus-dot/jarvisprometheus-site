import json
import unittest
from forge.contracts import parse_model_reasoning,ContractError

class EnvelopeTest(unittest.TestCase):
    def body(self):
        return json.dumps({'schema_version':'forge.reasoning.v1','summary':'Amostra simulada.','signal_explanations':[{'signal':'temperature_c','explanation':'Inspeção humana.'}],'recommended_checks':['Solicitar inspeção do rolamento por um técnico.'],'uncertainty':'Causa não comprovada.'})
    def test_bare_and_complete_fence_same_contract(self):
        body=self.body()
        self.assertEqual(parse_model_reasoning(body),parse_model_reasoning('```json\n'+body+'\n```'))
    def test_prose_partial_fence_and_extra_fields_blocked(self):
        for raw in ['Here is JSON: '+self.body(),'```json\n'+self.body(),self.body()+' trailing text','```json\n{"extra":true}\n```']:
            with self.subTest(raw=raw),self.assertRaises(ContractError):parse_model_reasoning(raw)
