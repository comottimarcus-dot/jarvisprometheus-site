from datetime import datetime,timedelta,timezone
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from uuid import uuid4
from forge.ingest import TelemetryStore
from forge.industrial_execution import IndustrialService

FIX=Path(__file__).resolve().parents[1]/"fixtures"

class Runtime:
    def __init__(self):self.calls=[];self.after=None;self.bad={}
    def execute(self,directive,*,expected_executor_id):
        self.calls.append((directive,expected_executor_id))
        if self.after:self.after()
        body={"schema_version":"forge.reasoning.v1","summary":"Temperatura registrada requer inspeção humana.",
            "signal_explanations":[{"signal":"temperature_c","explanation":"Valor recebido na amostra simulada."}],
            "recommended_checks":["Solicitar inspeção do rolamento por um técnico."],"uncertainty":"Telemetria simulada; causa não comprovada."}
        return types.SimpleNamespace(succeeded=True,output={"physical_execution":True,
            "executor_id":"amd-mi300x-vllm","route_key":"amd-mi300x-reasoning","finish_reason":"stop",
            "model":"mock-model","content":json.dumps(body),"completion_id":"MOCK-NOT-LIVE",**self.bad})

class IndustrialTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        (self.root/".runtime").mkdir(mode=0o700)
        self.clock=100.0;self.store=TelemetryStore(str(self.root/".runtime/replay.db"),clock=lambda:self.clock)
        self.env={"JARVIS_MI300X_ENABLED":"1","JARVIS_MI300X_BASE_URL":"http://127.0.0.1:9999","JARVIS_MI300X_MODEL":"mock-model"}
        self.service=IndustrialService(self.store,self.root,environ=self.env)
        self.runtime=Runtime()
    def tearDown(self):self.service.close();self.store.close();self.tmp.cleanup()
    def sample(self,name="normal"):
        self.store.receive((FIX/f"{name}.json").read_bytes(),authenticated=True)
    def request(self):return {"operation":"forge_check_asset","request_id":str(uuid4()),"asset_id":"P-204"}
    def authorize(self,**changes):
        d={"campaign":"act3","authorization_id":"MOCK-ALLOCATION",
            "endpoint_sha256":hashlib.sha256(self.env["JARVIS_MI300X_BASE_URL"].encode()).hexdigest(),
            "max_requests":3,"expires_at":(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),**changes}
        p=self.root/".runtime/compute-allocation.json";p.write_text(json.dumps(d));p.chmod(0o600)
    def test_existing_x6_ingress_and_frozen_context(self):
        self.sample("critical");self.authorize()
        result=self.service.execute(self.request(),self.runtime)
        self.assertTrue(result["ok"])
        self.assertEqual(result["schema_version"],"forge.result.v1")
        self.assertTrue(result["simulated"])
        directive,executor=self.runtime.calls[0]
        self.assertEqual(executor,"amd-mi300x-vllm")
        self.assertEqual(directive.target,"amd-mi300x-reasoning")
        self.assertNotIn('"scenario"',directive.payload["prompt"])
        self.assertEqual(result["severity"],"critical")
        self.assertEqual(directive.metadata["sample_sha256"],result["sample_reference"]["sample_sha256"])
        self.assertFalse(result["governance"]["physical_actuation_authorized"])
    def test_no_allocation_no_compute(self):
        self.sample()
        r=self.service.execute(self.request(),self.runtime)
        self.assertEqual(r["reason"],"FORGE_COMPUTE_NOT_AUTHORIZED")
        self.assertEqual(len(self.runtime.calls),0)
    def test_academy_wrong_endpoint_and_expiry_blocked(self):
        self.sample()
        for change in ({"campaign":"academy"},{"endpoint_sha256":"bad"},{"expires_at":"2020-01-01T00:00:00+00:00"}):
            self.authorize(**change)
            self.assertFalse(self.service.execute(self.request(),self.runtime)["ok"])
        self.assertEqual(len(self.runtime.calls),0)
    def test_unavailable_stale_and_offline_no_compute(self):
        self.authorize()
        self.assertFalse(self.service.execute(self.request(),self.runtime)["ok"])
        self.sample();self.clock+=6
        self.assertEqual(self.service.execute(self.request(),self.runtime)["reason"],"TELEMETRY_STALE")
        self.store.transport_lost()
        self.assertEqual(self.service.execute(self.request(),self.runtime)["reason"],"TELEMETRY_OFFLINE")
        self.assertEqual(len(self.runtime.calls),0)
    def test_duplicate_and_quota(self):
        self.sample();self.authorize(max_requests=1)
        q=self.request();self.assertTrue(self.service.execute(q,self.runtime)["ok"])
        self.assertEqual(self.service.execute(q,self.runtime)["reason"],"REQUEST_ALREADY_ADMITTED")
        self.assertEqual(self.service.execute(self.request(),self.runtime)["reason"],"FORGE_REQUEST_BUDGET_EXHAUSTED")
        self.assertEqual(len(self.runtime.calls),1)
    def test_budget_ledger_survives_service_restart(self):
        self.sample();self.authorize();q=self.request();self.service.execute(q,self.runtime)
        self.service.close();self.service=IndustrialService(self.store,self.root,environ=self.env)
        self.assertEqual(self.service.execute(q,self.runtime)["reason"],"REQUEST_ALREADY_ADMITTED")
        self.assertEqual(len(self.runtime.calls),1)
    def test_response_expired_is_historical(self):
        self.sample();self.authorize();self.runtime.after=lambda:setattr(self,"clock",self.clock+6)
        r=self.service.execute(self.request(),self.runtime)
        self.assertTrue(r["ok"]);self.assertEqual(r["scope"],"historical_sample")
        self.assertEqual(r["governance"]["gate_result"],"blocked")
        self.assertNotIn("Recomendações para revisão humana:",r["response"])
    def test_mismatched_or_invalid_model_result_does_not_retry(self):
        self.sample();self.authorize(max_requests=10)
        for bad in ({"executor_id":"wrong"},{"model":"wrong"},{"finish_reason":"length"},{"content":"not json"}):
            self.runtime.bad=bad
            r=self.service.execute(self.request(),self.runtime)
            self.assertFalse(r["ok"]);self.assertTrue(r["execution_attempted"])
        self.assertEqual(len(self.runtime.calls),4)
    def test_busy_never_enters_runtime(self):
        self.sample();self.authorize();self.service.lock.acquire()
        try:self.assertEqual(self.service.execute(self.request(),self.runtime)["reason"],"FORGE_BUSY")
        finally:self.service.lock.release()
        self.assertEqual(len(self.runtime.calls),0)

    def test_unsafe_recommendation_blocked_after_single_execution(self):
        self.sample("critical");self.authorize()
        self.runtime.bad={"content":json.dumps({"schema_version":"forge.reasoning.v1","summary":"Inspeção.","signal_explanations":[{"signal":"temperature_c","explanation":"Amostra simulada."}],"recommended_checks":["Desligar a bomba automaticamente."],"uncertainty":"Causa incerta."})}
        r=self.service.execute(self.request(),self.runtime)
        self.assertEqual(r["reason"],"GOVERNANCE_RECOMMENDATION_REJECTED")
        self.assertTrue(r["execution_attempted"])
        self.assertFalse(r["governance"]["physical_actuation_authorized"])
        self.assertNotIn("Desligar",r["response"])
        self.assertEqual(len(self.runtime.calls),1)

    def test_explicit_academy_forge_override_has_truthful_provenance(self):
        self.sample();self.authorize(campaign="academy",purpose="forge_user_authorized",max_requests=1)
        r=self.service.execute(self.request(),self.runtime)
        self.assertTrue(r["ok"])
        self.assertEqual(r["funding"]["credit_campaign"],"academy")
        self.assertEqual(self.runtime.calls[0][0].metadata["credit_campaign"],"academy")
        self.assertEqual(self.service.execute(self.request(),self.runtime)["reason"],"FORGE_REQUEST_BUDGET_EXHAUSTED")

    def test_rejected_model_preserves_confirmed_execution_privately(self):
        self.sample();self.authorize();self.runtime.bad={"content":"Here is a response, not JSON"}
        q=self.request();r=self.service.execute(q,self.runtime)
        self.assertEqual(r["reason"],"INVALID_JSON")
        self.assertTrue(r["amd_completion_confirmed"])
        self.assertEqual(r["execution"]["executor_id"],"amd-mi300x-vllm")
        self.assertNotIn("Here is",json.dumps(r))
        p=self.root/".runtime"/("model-rejected-"+q["request_id"]+".json")
        self.assertEqual(p.stat().st_mode & 0o777,0o600)

    def test_unlimited_allocation_preserves_duplicate_guard(self):
        self.sample();self.authorize(campaign="academy",purpose="forge_user_authorized",max_requests=None)
        q=self.request();self.assertTrue(self.service.execute(q,self.runtime)["ok"])
        self.assertEqual(self.service.execute(q,self.runtime)["reason"],"REQUEST_ALREADY_ADMITTED")
        for _ in range(4):self.assertTrue(self.service.execute(self.request(),self.runtime)["ok"])
        self.assertEqual(len(self.runtime.calls),5)
    def test_expected_scenario_blocks_before_compute(self):
        self.sample("normal");self.authorize(max_requests=None)
        q={**self.request(),"expected_severity":"warning"}
        r=self.service.execute(q,self.runtime)
        self.assertEqual(r["reason"],"SCENARIO_MISMATCH")
        self.assertEqual(r["snapshot"]["severity"],"normal")
        self.assertEqual(len(self.runtime.calls),0)
        self.assertEqual(self.service.db.execute("SELECT count(*) FROM requests").fetchone()[0],0)

    def test_local_status_requires_no_allocation_or_execution(self):
        self.sample('warning')
        q={**self.request(),'operation':'forge_asset_status','language':'en'}
        r=self.service.status(q)
        self.assertTrue(r['ok']);self.assertFalse(r['executed_now'])
        self.assertEqual(r['snapshot']['severity'],'warning')
        self.assertIn('No AMD inference was requested',r['response'])
        self.assertEqual(len(self.runtime.calls),0)
    def test_english_historical_response_and_checks(self):
        from forge.governance import ALLOWED_CHECKS_EN
        self.sample('critical');self.authorize()
        self.runtime.after=lambda:setattr(self,'clock',self.clock+6)
        self.runtime.bad={'content':json.dumps({'schema_version':'forge.reasoning.v1','summary':'Simulated sample.','signal_explanations':[{'signal':'temperature_c','explanation':'Human inspection.'}],'recommended_checks':[ALLOWED_CHECKS_EN[0]],'uncertainty':'Cause unknown.'})}
        r=self.service.execute({**self.request(),'language':'en'},self.runtime)
        self.assertTrue(r['ok']);self.assertEqual(r['language'],'en')
        self.assertIn('Historical analysis',r['response'])
        self.assertFalse(r['current_state_claim'])
