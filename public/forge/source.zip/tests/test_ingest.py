import json
from pathlib import Path
import tempfile
import unittest
from forge.ingest import TelemetryStore

FIX=Path(__file__).resolve().parents[1]/"fixtures/normal.json"

class IngestTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.now=100.0
        self.path=str(Path(self.tmp.name)/"replay.db")
        self.store=TelemetryStore(self.path,clock=lambda:self.now)
    def tearDown(self):
        self.store.close();self.tmp.cleanup()
    def wire(self,**changes):
        d=json.loads(FIX.read_text());d.update(changes);return json.dumps(d)
    def receive(self,raw=None,**kwargs):
        return self.store.receive(self.wire() if raw is None else raw,authenticated=True,**kwargs)
    def test_authenticated_fresh_and_ttl(self):
        self.assertTrue(self.receive()["accepted"])
        self.assertEqual(self.store.snapshot()["severity"],"normal")
        self.now+=5;self.assertEqual(self.store.snapshot()["availability"],"fresh")
        self.now+=.01;self.assertEqual((self.store.snapshot()["availability"],self.store.snapshot()["severity"]),("stale",None))
    def test_duplicate_cannot_refresh_or_clear_latest_error(self):
        self.receive();self.now+=6
        self.assertEqual(self.receive()["reason"],"DUPLICATE_IGNORED")
        self.assertEqual(self.store.snapshot()["availability"],"stale")
        self.receive("bad");self.receive()
        self.assertEqual(self.store.snapshot()["availability"],"invalid")
        self.receive(self.wire(sequence=2,uptime_ms=2000))
        self.assertEqual(self.store.snapshot()["availability"],"fresh")
    def test_conflict_and_order(self):
        self.receive(self.wire(sequence=10))
        self.assertEqual(self.receive(self.wire(sequence=9))["reason"],"OLD_SEQUENCE")
        self.assertEqual(self.receive(self.wire(sequence=10,uptime_ms=1001))["reason"],"CONFLICTING_DUPLICATE")
        self.assertEqual(self.receive(self.wire(sequence=11,uptime_ms=999))["reason"],"UPTIME_REGRESSION")
    def test_retired_boot_survives_restart(self):
        self.receive()
        other="00000000-0000-4000-8000-000000000002"
        self.receive(self.wire(boot_id=other))
        self.store.close();self.store=TelemetryStore(self.path,clock=lambda:self.now)
        self.assertEqual(self.receive(self.wire(sequence=2))["reason"],"RETIRED_BOOT")
        self.assertTrue(self.receive(self.wire(boot_id=other,sequence=2,uptime_ms=2000))["accepted"])
    def test_restart_does_not_restore_freshness(self):
        self.receive();self.store.close();self.store=TelemetryStore(self.path,clock=lambda:self.now)
        self.assertEqual(self.store.snapshot()["availability"],"unavailable")
        self.assertEqual(self.receive()["reason"],"DUPLICATE_IGNORED")
        self.assertIsNone(self.store.snapshot()["severity"])
        self.assertTrue(self.receive(self.wire(sequence=2))["accepted"])
    def test_retained_auth_and_wrong_topic(self):
        self.assertEqual(self.store.receive(self.wire())["reason"],"UNAUTHENTICATED_TRANSPORT")
        self.assertEqual(self.receive(retained=True)["reason"],"RETAINED_TELEMETRY")
        self.assertEqual(self.receive(topic="other")["reason"],"UNEXPECTED_TOPIC")
        self.assertIsNone(self.store.snapshot()["severity"])
    def test_lost_transport_and_counter_bounds(self):
        self.receive();self.store.transport_lost()
        self.assertEqual(self.store.snapshot()["availability"],"offline")
        self.assertIsNone(self.store.snapshot()["severity"])
        self.assertEqual(self.receive(self.wire(sequence=2**63))["reason"],"COUNTER_TOO_LARGE")
    def test_boot_history_is_bounded(self):
        for i in range(1024):
            bid=f"00000000-0000-4000-8000-{i:012x}"
            self.assertTrue(self.receive(self.wire(boot_id=bid))["accepted"])
        self.assertEqual(self.receive(self.wire(boot_id="00000000-0000-4000-8000-000000000fff"))["reason"],"BOOT_HISTORY_LIMIT")

    def test_disconnect_before_first_sample_is_offline(self):
        self.store.transport_lost()
        self.assertEqual(self.store.snapshot()["availability"],"offline")
        self.assertIsNone(self.store.snapshot()["severity"])
