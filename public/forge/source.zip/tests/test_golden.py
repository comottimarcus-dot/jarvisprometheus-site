import unittest
from uuid import uuid4
from forge.golden import assess_run
from forge.governance import ALLOWED_CHECKS,GATE_VERSION

class GoldenTest(unittest.TestCase):
    def result(self):
        return {'schema_version':'forge.result.v1','operation':'forge_check_asset','asset_id':'P-204','simulated':True,'request_id':str(uuid4()),'ok':True,'executed_now':True,'historical':False,'scope':'simulated_industrial_recommendation','current_state_claim':True,'severity':'warning','execution':{'executor_id':'amd-mi300x-vllm','route_key':'amd-mi300x-reasoning','completion_id':'cmpl-example','model':'example-model'},'sample_reference':{'sample_sha256':'a'*64},'governance':{'policy_version':GATE_VERSION,'human_review_required':True,'model_prose_published':False,'physical_actuation_authorized':False,'physical_actuation_performed':False,'gate_result':'recommendation_allowed'},'reasoning':{'recommended_checks':[ALLOWED_CHECKS[0]]}}
    def test_backend_cannot_certify_voice(self):
        a=assess_run(self.result(),'warning')
        self.assertTrue(a['backend_evidence_pass'])
        self.assertFalse(a['full_golden_run_complete']);self.assertFalse(a['acoustic_return_verified'])
    def test_mock_wrong_severity_or_actuation_cannot_pass(self):
        d=self.result();d['execution']['completion_id']='MOCK-NOT-LIVE'
        self.assertFalse(assess_run(d,'warning')['backend_evidence_pass'])
        d=self.result();self.assertFalse(assess_run(d,'critical')['backend_evidence_pass'])
        d['governance']['physical_actuation_authorized']=True
        self.assertFalse(assess_run(d,'warning')['backend_evidence_pass'])
    def test_historical_run_cannot_publish_current_recommendation(self):
        d=self.result();d.update(historical=True,scope='historical_sample',current_state_claim=False)
        d['governance']['gate_result']='blocked'
        self.assertFalse(assess_run(d,'warning')['backend_evidence_pass'])
        d['reasoning']['recommended_checks']=[]
        self.assertTrue(assess_run(d,'warning')['backend_evidence_pass'])

    def test_english_checks_use_english_allowlist(self):
        from forge.governance import ALLOWED_CHECKS_EN
        d=self.result();d['language']='en';d['reasoning']['recommended_checks']=[ALLOWED_CHECKS_EN[0]]
        self.assertTrue(assess_run(d,'warning')['backend_evidence_pass'])
