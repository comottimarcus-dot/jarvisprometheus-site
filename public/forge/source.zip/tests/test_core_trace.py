import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from uuid import uuid4
from forge.core_adapter import dispatch_forge

class TraceTest(unittest.IsolatedAsyncioTestCase):
    async def test_blocked_result_has_correlated_events_without_success_claim(self):
        request_id=str(uuid4())
        cognitive=SimpleNamespace(event_bus=SimpleNamespace(publish=AsyncMock()))
        with patch('forge.core_adapter._execute',return_value={'ok':False,'executed_now':False,'reason':'FORGE_COMPUTE_NOT_AUTHORIZED'}):
            result=await dispatch_forge(cognitive,{'operation':'forge_check_asset','request_id':request_id,'asset_id':'P-204'})
        self.assertEqual(result['thought_id'],'forge-'+request_id)
        self.assertEqual(cognitive.event_bus.publish.await_count,2)
        for call in cognitive.event_bus.publish.await_args_list:self.assertEqual(call.args[0].thought_id,result['thought_id'])
        last=cognitive.event_bus.publish.await_args_list[-1].args[0]
        self.assertFalse(last.payload['execution_results'][0]['success'])
