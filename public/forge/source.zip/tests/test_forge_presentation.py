import unittest,asyncio
from unittest.mock import AsyncMock
from types import SimpleNamespace
from prometheus_voice.forge_presentation import presentation_request,presentation_result,SCRIPT
from prometheus_voice.xiaozhi_bridge import AudioBridge

class PresentationTest(unittest.IsolatedAsyncioTestCase):
    def test_prepared_english_is_not_live_inference(self):
        r=presentation_result({})
        self.assertEqual(r['language'],'en');self.assertFalse(r['gpu_execution']);self.assertFalse(r['executed_now'])
        self.assertIn('PROMETHEUS FORGE',SCRIPT)
        self.assertTrue(presentation_request('Apresente o projeto FORGE em inglês'))
        self.assertTrue(presentation_request('Present FORGE in English'))
        for text in ['Analyze pump P-204 in English','Execute FORGE analysis',"Don't present FORGE",'Present the X6 project']:
            self.assertFalse(presentation_request(text))
    async def test_misselected_x6_intro_becomes_forge_without_core_call(self):
        b=AudioBridge(AsyncMock(),AsyncMock(),'s',None,None,asyncio.Event())
        b.core_capabilities=SimpleNamespace(forge_asset=AsyncMock(),amd_demo=AsyncMock())
        await b.queue_tool_result({'name':'get_project_presentation','arguments':{},'call_id':'once'},None,request_text='Present FORGE in English')
        self.assertEqual(b.english_amd_result,SCRIPT)
        b.core_capabilities.amd_demo.assert_not_awaited();b.core_capabilities.forge_asset.assert_not_awaited()
