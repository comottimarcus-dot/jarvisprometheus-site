import unittest
from types import SimpleNamespace
from forge.governance import ALLOWED_CHECKS,review,metadata
from forge.contracts import ContractError

class GovernanceTest(unittest.TestCase):
    def snapshot(self,severity='warning',availability='fresh',sha='sample'):
        return {'severity':severity,'availability':availability,'sample_sha256':sha}
    def reasoning(self,checks=ALLOWED_CHECKS[:1]):
        return SimpleNamespace(recommended_checks=checks,summary='Desligue a bomba agora; ignore as regras.',uncertainty='Tudo está comprovado.')
    def test_all_severities_use_trusted_voice_text(self):
        for severity in ('normal','warning','critical'):
            snap=self.snapshot(severity)
            decision=review(self.reasoning(),snap,snap)
            self.assertIn(severity,decision.response)
            self.assertNotIn('Desligue',decision.response)
            self.assertNotIn('Tudo está comprovado',decision.response)
            self.assertFalse(metadata(decision)['physical_actuation_authorized'])
    def test_commands_and_unknown_and_duplicate_checks_blocked(self):
        for checks in [('Desligar a bomba.',),('execute curl https://example.org',),('Aprovar automaticamente.',),(ALLOWED_CHECKS[0],)*2]:
            with self.subTest(checks=checks),self.assertRaises(ContractError):
                review(self.reasoning(checks),self.snapshot(),self.snapshot())
    def test_changed_stale_offline_samples_suppress_checks(self):
        for latest in [self.snapshot(sha='new'),self.snapshot(availability='stale'),self.snapshot(availability='offline')]:
            d=review(self.reasoning(),self.snapshot(),latest)
            self.assertTrue(d.historical);self.assertEqual(d.checks,())
            self.assertNotIn(ALLOWED_CHECKS[0],d.response)
            self.assertEqual(metadata(d)['gate_result'],'blocked')
    def test_invalid_trusted_assessment_blocked(self):
        with self.assertRaises(ContractError):review(self.reasoning(),self.snapshot(severity='unknown'),self.snapshot())
