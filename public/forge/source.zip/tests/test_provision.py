import contextlib
import io
import json
from pathlib import Path
import runpy
import tempfile
import types
import unittest
from unittest.mock import patch

SCRIPT=Path(__file__).resolve().parents[1]/"scripts/provision.py"

class SerialTimeout(Exception):pass

class ProvisionTest(unittest.TestCase):
    def run_script(self, mode):
        state={"writes":[],"opened":False,"closed":False,"dtr":None,"rts":None}
        class Port:
            def __init__(self,**kwargs):self.dtr=True;self.rts=True
            def open(self):state.update(opened=True,dtr=self.dtr,rts=self.rts)
            def close(self):state["closed"]=True
            def readline(self):
                if not state["writes"]:return b"" if mode=="no_boot" else b"FORGE_CONFIG_READY\n"
                return b"FORGE_CONFIG_REJECTED\n" if mode=="reject" else b"FORGE_CONFIG_SAVED\n"
            def write(self, data):
                if mode=="timeout":raise SerialTimeout("secret should not be exposed")
                state["writes"].append(data);return len(data)
            def flush(self):pass
        clock=[0.0]
        def tick():clock[0]+=.1;return clock[0]
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/"scripts").mkdir();(root/".runtime").mkdir()
            (root/"scripts/provision.py").write_text(SCRIPT.read_text())
            f=root/".runtime/provision.json"
            f.write_text(json.dumps({"password":"DUMMY_PRIVATE_VALUE","ca":"x"*400,"epoch":0}));f.chmod(0o600)
            output=io.StringIO();error=None
            with patch.dict("sys.modules",{"serial":types.SimpleNamespace(Serial=Port,SerialTimeoutException=SerialTimeout)}),patch("time.monotonic",tick),patch("time.sleep"),contextlib.redirect_stdout(output):
                try:runpy.run_path(str(root/"scripts/provision.py"),run_name="__main__")
                except SystemExit as exc:error=str(exc)
            return state,output.getvalue(),error
    def test_success_chunked_after_live_marker(self):
        state,out,error=self.run_script("ok")
        self.assertIsNone(error)
        self.assertTrue(state["closed"])
        self.assertFalse(state["dtr"]);self.assertFalse(state["rts"])
        self.assertTrue(all(len(x)<=64 for x in state["writes"]))
        self.assertTrue(b"".join(state["writes"]).endswith(b"\n"))
        self.assertIn("PROVISIONING_CONFIRMED",out)
        self.assertNotIn("DUMMY_PRIVATE_VALUE",out)
    def test_no_boot_never_sends_credentials(self):
        state,out,error=self.run_script("no_boot")
        self.assertEqual(state["writes"],[])
        self.assertIn("EDGE_FIRMWARE_NOT_READY",error)
        self.assertNotIn("PROVISIONING_CONFIRMED",out)
    def test_rejected_is_not_confirmed(self):
        state,out,error=self.run_script("reject")
        self.assertEqual(error,"PROVISIONING_REJECTED")
        self.assertNotIn("PROVISIONING_CONFIRMED",out)
    def test_timeout_is_bounded_and_redacted(self):
        state,out,error=self.run_script("timeout")
        self.assertTrue(state["closed"])
        self.assertIn("PROVISION_USB_WRITE_TIMEOUT",error)
        self.assertNotIn("secret",error)
