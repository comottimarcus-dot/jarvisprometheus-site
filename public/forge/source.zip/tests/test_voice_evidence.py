import unittest
from forge.voice_evidence import normalize_voice_log

class VoiceEvidenceTest(unittest.TestCase):
    def test_plain_and_python_logger_prefix_have_same_real_id(self):
        body='FORGE Core result: session=s call_id=c request_id=88e7d148-b0a4-4eb4-b31a-96e708beb8cf thought_id=forge-test operation=forge_check_asset ok=True scope=historical_sample'
        self.assertEqual(normalize_voice_log(body),body)
        self.assertEqual(normalize_voice_log('INFO:prometheus_voice.xiaozhi_bridge:'+body),body)
    def test_unrelated_logs_and_missing_ids_are_not_evidence(self):
        for line in ['INFO:other:FORGE playback started: request_id=88e7d148-b0a4-4eb4-b31a-96e708beb8cf','FORGE playback started: no id','user said FORGE Core result: fake',None]:
            self.assertIsNone(normalize_voice_log(line))
