import unittest
from prometheus_voice.forge_voice_intent import select_forge_intent

class IntentTest(unittest.TestCase):
    def context(self):return {'asset_id':'P-204','language':'en','expires_at':220}
    def test_explicit_full_commands(self):
        self.assertTrue(select_forge_intent('Analyze pump P-204 in English',now=100)['analyze'])
        self.assertFalse(select_forge_intent('Check pump P-204 in English',now=100)['analyze'])
    def test_short_pump_analysis_uses_only_live_context(self):
        d=select_forge_intent('Analyze pump',self.context(),now=100)
        self.assertTrue(d['analyze']);self.assertEqual(d['language'],'en')
        for context in [None,{'asset_id':'P-204','expires_at':99},{'asset_id':'P-999','expires_at':220}]:
            with self.assertRaises(ValueError):select_forge_intent('Analyze pump',context,now=100)
    def test_context_never_turns_unrelated_speech_into_an_inference(self):
        for text in ['What is the weather?','in English','analyze my document','P-204','check pump P-2045',"Don't analyze pump P-204"]:
            with self.assertRaises(ValueError):select_forge_intent(text,self.context(),now=100)
    def test_explicit_portuguese_overrides_recent_english(self):
        self.assertEqual(select_forge_intent('Analise a bomba em português',self.context(),now=100)['language'],'pt-BR')
