import copy
import json
from pathlib import Path
import unittest
from forge.contracts import ContractError, parse_telemetry, parse_query, parse_reasoning
from forge.policy import assess

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"

def sample(name="normal"):
    return json.loads((FIXTURES / f"{name}.json").read_text())

def wire(data):
    return json.dumps(data)

class ContractsTest(unittest.TestCase):
    def reject(self, data, code=None):
        with self.assertRaises(ContractError) as caught:
            parse_telemetry(wire(data))
        if code:
            self.assertEqual(caught.exception.code, code)

    def test_fixtures_and_independent_scenario_labels(self):
        for expected in ("normal", "warning", "critical"):
            for label in ("normal", "warning", "critical"):
                with self.subTest(expected=expected, label=label):
                    data = sample(expected); data["scenario"] = label
                    result = assess(wire(data), age_ms=0)
                    self.assertEqual(result.severity, expected)
                    self.assertEqual(result.availability, "fresh")

    def test_hash_order_and_immutable_snapshot(self):
        data = sample()
        original = parse_telemetry(wire(data))
        reversed_data = dict(reversed(list(data.items())))
        self.assertEqual(original.sample_sha256, parse_telemetry(wire(reversed_data)).sample_sha256)
        data["signals"]["temperature_c"] = 96
        copy_values = original.signal_values(); copy_values["temperature_c"] = 140
        self.assertEqual(original.signal_values()["temperature_c"], 64)
        self.assertNotEqual(original.sample_sha256, parse_telemetry(wire(data)).sample_sha256)

    def test_exact_fields(self):
        for key in sample():
            data = sample(); del data[key]
            with self.subTest(missing=key): self.reject(data, "INVALID_FIELDS")
        data = sample(); data["endpoint"] = "http://example.invalid"; self.reject(data)
        data = sample(); data["signals"]["unknown"] = 1; self.reject(data)
        data = sample(); del data["signals"]["rpm"]; self.reject(data)

    def test_identity_schema_and_simulation(self):
        for key, value in [("asset_id","P-205"),("node_id","other"),
            ("schema_version","forge.telemetry.v2"),("simulated",False),("simulated",1),
            ("scenario",[]),("boot_id","not-uuid"),
            ("boot_id","00000000-0000-1000-8000-000000000001")]:
            data=sample(); data[key]=value
            with self.subTest(key=key,value=value): self.reject(data)

    def test_numeric_coercion_and_ranges(self):
        for key in sample()["signals"]:
            for value in (True,"1",None,-1000,100000):
                data=sample(); data["signals"][key]=value
                with self.subTest(key=key,value=value): self.reject(data)
        for key in ("sequence","uptime_ms"):
            for value in (True,1.0,-1,"1"):
                data=sample(); data[key]=value
                with self.subTest(key=key,value=value): self.reject(data)
        for key in ("rpm","maintenance_overdue_hours"):
            data=sample(); data["signals"][key]=1.0; self.reject(data)

    def test_wire_rejection(self):
        cases=[b"{}"*2,b"\xff",b"[]",b"null",b'{"scenario":"normal","scenario":"critical"}',
               b'"'+b'x'*2048+b'"',b'['*1000+b']'*1000]
        for raw in cases:
            with self.subTest(raw=raw[:30]), self.assertRaises(ContractError): parse_telemetry(raw)
        for token in ("NaN","Infinity","-Infinity","1e999"):
            raw=wire(sample()).replace('64',token,1)
            with self.subTest(token=token),self.assertRaises(ContractError):parse_telemetry(raw)
        with self.assertRaises(ContractError):parse_telemetry(sample())

    def test_duplicate_nested_key(self):
        raw=wire(sample()).replace('"temperature_c": 64','"temperature_c": 64, "temperature_c": 96')
        with self.assertRaises(ContractError) as caught: parse_telemetry(raw)
        self.assertEqual(caught.exception.code,"DUPLICATE_JSON_KEY")

    def test_freshness_and_unavailable_states(self):
        raw=wire(sample())
        self.assertEqual(assess(raw,age_ms=5000).severity,"normal")
        result=assess(raw,age_ms=5000.01)
        self.assertEqual((result.availability,result.severity),("stale",None))
        for args,state in [({"age_ms":None},"unavailable"),
             ({"age_ms":0,"connected":False},"offline"),
             ({"age_ms":0,"latest_message_valid":False},"invalid")]:
            r=assess(None,**args);self.assertEqual((r.availability,r.severity),(state,None))
        r=assess(b"bad json",age_ms=0);self.assertEqual((r.availability,r.severity),("invalid",None))
        for age in (None,True,-1,float("nan"),float("inf"),"0"):
            with self.subTest(age=age),self.assertRaises(ContractError):assess(raw,age_ms=age)
        with self.assertRaises(ContractError):assess(raw,age_ms=0,connected=1)

    def test_threshold_boundaries_and_highest_severity(self):
        cases=[("temperature_c",74.99,"normal"),("temperature_c",75,"warning"),
               ("temperature_c",90,"critical"),("vibration_rms_mm_s",4,"warning"),
               ("vibration_rms_mm_s",7,"critical"),("pressure_bar",5.8,"normal"),
               ("pressure_bar",4.5,"warning"),("pressure_bar",4.49,"critical"),
               ("motor_current_a",14,"warning"),("motor_current_a",17,"critical"),
               ("rpm",1475,"normal"),("rpm",1474,"warning"),("rpm",1400,"warning"),
               ("rpm",1399,"critical"),("maintenance_overdue_hours",1,"warning"),
               ("maintenance_overdue_hours",168,"critical")]
        for key,value,expected in cases:
            data=sample();data["signals"][key]=value
            with self.subTest(key=key,value=value):
                result=assess(wire(data),age_ms=0);self.assertEqual(result.severity,expected)
                for finding in result.findings:self.assertEqual(finding.value,data["signals"][finding.signal])
        data=sample();data["signals"]["temperature_c"]=80;data["signals"]["rpm"]=1390
        r=assess(wire(data),age_ms=0);self.assertEqual(r.severity,"critical")
        self.assertEqual({f.severity for f in r.findings},{"warning","critical"})

    def test_query_cannot_override_context(self):
        data={"schema_version":"forge.query.v1","request_id":"00000000-0000-4000-8000-000000000002","asset_id":"P-204"}
        self.assertEqual(parse_query(wire(data)).asset_id,"P-204")
        for key,value in [("prompt","stop pump"),("endpoint","http://example.invalid"),("signals",sample()["signals"])]:
            bad={**data,key:value}
            with self.subTest(key=key),self.assertRaises(ContractError):parse_query(wire(bad))
        data["asset_id"]="other"
        with self.assertRaises(ContractError):parse_query(wire(data))

    def test_reasoning_contract_no_authority_fields(self):
        data={"schema_version":"forge.reasoning.v1","summary":"Inspect pump signals.",
            "signal_explanations":[{"signal":"temperature_c","explanation":"Temperature is elevated."}],
            "recommended_checks":["Ask the operator to inspect the bearing."],
            "uncertainty":"These are simulated measurements."}
        self.assertEqual(len(parse_reasoning(wire(data)).recommended_checks),1)
        for key in ("severity","asset_id","physical_actuation_authorized","route"):
            bad={**data,key:True}
            with self.subTest(key=key),self.assertRaises(ContractError):parse_reasoning(wire(bad))
        for mutate in (lambda d:d.update(summary="x"*601),
                       lambda d:d.update(recommended_checks=["x"]*5),
                       lambda d:d.update(uncertainty=""),
                       lambda d:d["signal_explanations"][0].update(signal="invented"),
                       lambda d:d["signal_explanations"].append(d["signal_explanations"][0].copy()),
                       lambda d:d.update(summary="\ud800")):
            bad=copy.deepcopy(data);mutate(bad)
            with self.assertRaises(ContractError):parse_reasoning(wire(bad))
        with self.assertRaises(ContractError):parse_reasoning("```json\n"+wire(data)+"\n```")

if __name__ == "__main__":unittest.main()
