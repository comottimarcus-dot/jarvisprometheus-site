import asyncio,json,unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from prometheus_voice.config import Settings
from prometheus_voice.xiaozhi_bridge import handle_device
from test_voice_recovery import Device
from test_bridge_memory_lifecycle import ignore_transcripts

class ForgeLifecycleTest(unittest.IsolatedAsyncioTestCase):
    async def test_forge_english_switch_preserves_memory_without_reexecution(self):
        device=Device()
        memory=SimpleNamespace(scope='xiaozhi:device:'+'a'*24,saved_notes=[],load=AsyncMock(return_value=[]),append=AsyncMock())
        class Cloud:
            def __init__(self,events,last=False):self.events=events;self.last=last;self.sent=[]
            async def __aenter__(self):return self
            async def __aexit__(self,*args):pass
            async def send(self,raw):self.sent.append(json.loads(raw))
            async def __aiter__(self):
                yield json.dumps({'type':'session.ready'})
                for event in self.events:yield json.dumps(event)
                if self is first:
                    await asyncio.sleep(2)
                if self.last:
                    await device.queue.put(None);await asyncio.sleep(0)
        first=Cloud([{'type':'transcript.user','text':'Analise a bomba P-204 em inglês'}, {'type':'tool.call','name':'analyze_forge_asset','call_id':'amd-once','arguments':{'asset_id':'P-204'}}])
        english=Cloud([{'type':'reply.started','reply_id':'greeting'}, {'type':'transcript.agent','reply_id':'greeting','text':'Hello, judges.'}, {'type':'reply.done','reply_id':'greeting','status':'completed'}])
        normal=Cloud([{'type':'transcript.user','text':'Obrigado'}, {'type':'reply.started','reply_id':'normal'}, {'type':'transcript.agent','reply_id':'normal','text':'De nada.'}, {'type':'reply.done','reply_id':'normal','status':'completed'}],True)
        settings=Settings('unused',voice='rafael',xiaozhi_token='device-secret',core_memory_token='test')
        core=SimpleNamespace(forge_asset=AsyncMock(return_value={'ok':True,'executed_now':True,'language':'en','response':'Historical simulated sample.','request_id':'correlated-test','thought_id':'forge-test'}))
        with patch('prometheus_voice.xiaozhi_bridge.CoreCapabilityClient',return_value=core),patch('prometheus_voice.xiaozhi_bridge.CoreMemory',return_value=memory),patch('prometheus_voice.xiaozhi_bridge.connect',side_effect=[first,english,normal]),patch('prometheus_voice.xiaozhi_bridge.publish_transcripts',ignore_transcripts):
            await asyncio.wait_for(handle_device(device,settings),3)
        configs=[c.sent[0]['session'] for c in (first,english,normal)]
        self.assertEqual([c['output']['voice'] for c in configs],['rafael','charles','rafael'])
        self.assertEqual(configs[1]['greeting'],'Historical simulated sample.')
        core.forge_asset.assert_awaited_once_with('P-204',analyze=True,language='en')
        self.assertEqual(configs[1]['tools'],[])
        self.assertNotIn('greeting',configs[2])
        self.assertEqual(memory.load.await_count,3)
        self.assertEqual(memory.append.await_count,2)
        self.assertEqual(memory.append.await_args_list[0].args[1:], ('Analise a bomba P-204 em inglês', 'Historical simulated sample.'))
        self.assertEqual(memory.append.await_args.args[1:],('Obrigado','De nada.'))
        self.assertEqual(sum(e['type']=='hello' for e in device.sent),1)
        self.assertTrue(all(sum(e['type']=='session.update' for e in c.sent)==1 for c in (first,english,normal)))


    async def test_forge_prepared_intro_uses_english_voice_and_existing_memory(self):
        device=Device()
        memory=SimpleNamespace(scope='xiaozhi:device:'+'a'*24,saved_notes=[],load=AsyncMock(return_value=[]),append=AsyncMock())
        class Cloud:
            def __init__(self,events,last=False):self.events=events;self.last=last;self.sent=[]
            async def __aenter__(self):return self
            async def __aexit__(self,*args):pass
            async def send(self,raw):self.sent.append(json.loads(raw))
            async def __aiter__(self):
                yield json.dumps({'type':'session.ready'})
                for event in self.events:yield json.dumps(event)
                if self.last:
                    await device.queue.put(None);await asyncio.sleep(0)
        first=Cloud([{'type':'transcript.user','text':'Apresente o projeto FORGE em inglês'}])
        english=Cloud([{'type':'reply.started','reply_id':'greeting'}, {'type':'transcript.agent','reply_id':'greeting','text':'Hello, judges.'}, {'type':'reply.done','reply_id':'greeting','status':'completed'}])
        normal=Cloud([{'type':'transcript.user','text':'Obrigado'}, {'type':'reply.started','reply_id':'normal'}, {'type':'transcript.agent','reply_id':'normal','text':'De nada.'}, {'type':'reply.done','reply_id':'normal','status':'completed'}],True)
        settings=Settings('unused',voice='rafael',xiaozhi_token='device-secret',core_memory_token='test')
        core=SimpleNamespace(amd_demo=AsyncMock(),forge_asset=AsyncMock())
        with patch('prometheus_voice.xiaozhi_bridge.CoreCapabilityClient',return_value=core),patch('prometheus_voice.xiaozhi_bridge.CoreMemory',return_value=memory),patch('prometheus_voice.xiaozhi_bridge.connect',side_effect=[first,english,normal]),patch('prometheus_voice.xiaozhi_bridge.publish_transcripts',ignore_transcripts):
            await asyncio.wait_for(handle_device(device,settings),3)
        configs=[c.sent[0]['session'] for c in (first,english,normal)]
        self.assertEqual([c['output']['voice'] for c in configs],['rafael','charles','rafael'])
        self.assertIn('Hello, judges',configs[1]['greeting'])
        self.assertEqual(configs[1]['tools'],[])
        self.assertNotIn('greeting',configs[2])
        self.assertEqual(memory.load.await_count,3)
        self.assertEqual(memory.append.await_count,2)
        self.assertIn('PROMETHEUS FORGE',configs[1]['greeting'])
        core.amd_demo.assert_not_awaited();core.forge_asset.assert_not_awaited()
        self.assertEqual(memory.append.await_args.args[1:],('Obrigado','De nada.'))
        self.assertEqual(sum(e['type']=='hello' for e in device.sent),1)
        self.assertTrue(all(sum(e['type']=='session.update' for e in c.sent)==1 for c in (first,english,normal)))

