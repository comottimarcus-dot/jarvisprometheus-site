import asyncio,json,unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,patch
from prometheus_voice.core_capability_client import CoreCapabilityClient
from prometheus_voice.xiaozhi_bridge import AudioBridge
from prometheus_voice.x6_client import X6Unavailable

class Socket:
    async def __aenter__(self):return self
    async def __aexit__(self,*args):pass
    async def send(self,raw):self.request=json.loads(raw)
    async def recv(self):
        return json.dumps({**self.request,'schema_version':'forge.result.v1','simulated':True,'ok':True,'executed_now':self.request['operation']=='forge_check_asset','response':'Simulated historical result.','thought_id':'forge-'+self.request['request_id'],'governance':{'physical_actuation_authorized':False,'physical_actuation_performed':False}})

class ForgeVoiceTest(unittest.IsolatedAsyncioTestCase):
    def bridge(self):
        b=AudioBridge(AsyncMock(),AsyncMock(),'s',None,None,asyncio.Event())
        b.core_capabilities=SimpleNamespace(forge_asset=AsyncMock(return_value={'ok':True,'response':'Estado simulado warning.','language':'pt-BR','request_id':'test','thought_id':'forge-test'}))
        return b
    async def test_status_and_analysis_use_only_existing_endpoint(self):
        for analyze in (False,True):
            socket=Socket()
            with patch('prometheus_voice.core_capability_client.connect',return_value=socket) as conn:
                await CoreCapabilityClient('dummy','device-scope').forge_asset('P-204',analyze=analyze)
            self.assertEqual(socket.request['operation'],'forge_check_asset' if analyze else 'forge_asset_status')
            self.assertNotIn('device_scope',socket.request)
            self.assertEqual(conn.call_args.args[0],'ws://127.0.0.1:8765/voice-capability')
    async def test_status_cannot_claim_compute(self):
        socket=Socket();socket.recv=AsyncMock(return_value=json.dumps({'schema_version':'forge.result.v1','operation':'forge_asset_status','request_id':'wrong','asset_id':'P-204','simulated':True,'ok':True,'executed_now':True,'response':'invented','language':'pt-BR'}))
        with patch('prometheus_voice.core_capability_client.connect',return_value=socket):
            with self.assertRaises(X6Unavailable):await CoreCapabilityClient('dummy').forge_asset('P-204')
    async def test_status_does_not_select_analysis_and_duplicate_call_not_repeated(self):
        b=self.bridge();event={'name':'get_forge_asset_status','call_id':'a','arguments':{'asset_id':'P-204'}}
        await b.queue_tool_result(event,None,request_text='Verifique a bomba P-204')
        await b.queue_tool_result(event,None,request_text='Verifique a bomba P-204')
        b.core_capabilities.forge_asset.assert_awaited_once_with('P-204',analyze=False,language='pt-BR')
    async def test_unrelated_request_is_blocked_and_status_misselection_downgraded(self):
        b=self.bridge()
        await b.queue_tool_result({'name':'analyze_forge_asset','call_id':'a','arguments':{'asset_id':'P-204'}},None,request_text='Como está o tempo?')
        b.core_capabilities.forge_asset.assert_not_awaited()
        b=self.bridge()
        await b.queue_tool_result({'name':'analyze_forge_asset','call_id':'a','arguments':{'asset_id':'P-204'}},None,request_text='Verifique a bomba P-204')
        b.core_capabilities.forge_asset.assert_awaited_once_with('P-204',analyze=False,language='pt-BR')
    async def test_analysis_misselection_is_corrected_from_explicit_new_speech(self):
        b=self.bridge()
        await b.queue_tool_result({'name':'get_forge_asset_status','call_id':'a','arguments':{'asset_id':'P-204'}},None,request_text='Analyze pump P-204 in English')
        b.core_capabilities.forge_asset.assert_awaited_once_with('P-204',analyze=True,language='en')
    async def test_english_result_reuses_switch_payload(self):
        b=self.bridge();b.core_capabilities.forge_asset.return_value={'ok':True,'language':'en','response':'Historical simulated sample. No action performed.','request_id':'test','thought_id':'forge-test'}
        await b.queue_tool_result({'name':'analyze_forge_asset','call_id':'a','arguments':{'asset_id':'P-204'}},None,request_text='Analise a bomba P-204 em inglês')
        b.core_capabilities.forge_asset.assert_awaited_once_with('P-204',analyze=True,language='en')
        self.assertEqual(b.english_amd_result,b.core_capabilities.forge_asset.return_value['response'])
        self.assertEqual(b.pending_tool_results,[])
    async def test_interrupt_suppresses_late_result_without_claiming_cancellation(self):
        b=self.bridge()
        async def delayed(*args,**kwargs):
            await b.interrupt_reply()
            return {'ok':True,'response':'obsolete','language':'pt-BR'}
        b.core_capabilities.forge_asset.side_effect=delayed
        await b.queue_tool_result({'name':'analyze_forge_asset','call_id':'a','arguments':{'asset_id':'P-204'}},None,request_text='Analise a bomba P-204')
        self.assertEqual(b.pending_tool_results,[]);self.assertIsNone(b.forge_trace);self.assertIsNone(b.english_amd_result)
