import io
import contextlib
import types
import unittest
from unittest.mock import patch
from forge.query_core import load_token,TOKEN_PARSER_SOURCE

class CredentialsTest(unittest.TestCase):
    def setUp(self):
        patcher=patch("dotenv.dotenv_values",return_value={})
        patcher.start();self.addCleanup(patcher.stop)

    def test_core_dotenv_avoids_sudo(self):
        with patch.dict("os.environ",{},clear=True),patch("dotenv.dotenv_values",return_value={"JARVIS_VOICE_MEMORY_TOKEN":"dummy-token"}),patch("subprocess.run") as run:
            self.assertEqual(load_token(),"dummy-token")
            run.assert_not_called()

    def test_parser_only_selected_key(self):
        namespace={};exec(TOKEN_PARSER_SOURCE,namespace)
        text='OTHER_SECRET=do-not-return\nJARVIS_VOICE_MEMORY_TOKEN="dummy-token"\n'
        self.assertEqual(namespace["parse_token"](text),"dummy-token")
        for text in ('', 'JARVIS_VOICE_MEMORY_TOKEN=one\nJARVIS_VOICE_MEMORY_TOKEN=two',
                     'JARVIS_VOICE_MEMORY_TOKEN="bad token"', 'JARVIS_VOICE_MEMORY_TOKEN=$(command)'):
            with self.subTest(text=text),self.assertRaises(ValueError):namespace["parse_token"](text)
    def test_privileged_read_is_captured_and_fixed_path(self):
        out=io.StringIO()
        with patch.dict("os.environ",{},clear=True),patch("builtins.open",side_effect=PermissionError),patch("subprocess.run",return_value=types.SimpleNamespace(returncode=0,stdout="dummy-secret\n")) as run,contextlib.redirect_stdout(out):
            self.assertEqual(load_token(),"dummy-secret")
        args=run.call_args.args[0]
        self.assertEqual(args[:4],["sudo","--","/usr/bin/python3","-c"])
        self.assertIn("/etc/jarvis/voice-bridge.env",args[4])
        self.assertEqual(out.getvalue(),"")
    def test_sudo_failure_has_no_secret_or_trace(self):
        with patch.dict("os.environ",{},clear=True),patch("builtins.open",side_effect=PermissionError),patch("subprocess.run",return_value=types.SimpleNamespace(returncode=1,stdout="")):
            with self.assertRaises(SystemExit) as caught:load_token()
        self.assertIn("REQUIRES_SUDO",str(caught.exception))
    def test_env_token_avoids_privileged_reader(self):
        with patch.dict("os.environ",{"JARVIS_VOICE_MEMORY_TOKEN":"dummy-token"},clear=True),patch("subprocess.run") as run:
            self.assertEqual(load_token(),"dummy-token");run.assert_not_called()

    def test_reader_errors_are_distinct_and_sanitized(self):
        for code,marker in [(20,"CORE_TOKEN_DECLARATION_INVALID"),(21,"CORE_CREDENTIAL_FILE_UNREADABLE")]:
            with patch.dict("os.environ",{},clear=True),patch("builtins.open",side_effect=PermissionError),patch("subprocess.run",return_value=types.SimpleNamespace(returncode=code,stdout="")):
                with self.assertRaises(SystemExit) as caught:load_token()
                self.assertEqual(str(caught.exception),marker)
