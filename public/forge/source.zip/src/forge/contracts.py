"""Wire validation only: no MQTT, model execution or actuator authority."""
from dataclasses import dataclass
import hashlib
import json
import math
from uuid import UUID

MAX_TELEMETRY_BYTES = 2048
SIGNAL_RANGES = {
    "temperature_c": (-20, 150), "vibration_rms_mm_s": (0, 30),
    "pressure_bar": (0, 20), "motor_current_a": (0, 50),
    "rpm": (0, 4000), "maintenance_overdue_hours": (0, 8760),
}
INTEGER_SIGNALS = {"rpm", "maintenance_overdue_hours"}
SCENARIOS = ("normal", "warning", "critical")

class ContractError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def fail(code):
    raise ContractError(code)


def exact_keys(value, keys):
    if type(value) is not dict or set(value) != set(keys):
        fail("INVALID_FIELDS")


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            fail("DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def _constant(_value):
    fail("NONFINITE_JSON_NUMBER")


def _float(value):
    result = float(value)
    if not math.isfinite(result):
        fail("NONFINITE_JSON_NUMBER")
    return result


def load_wire(raw, limit):
    if type(raw) is str:
        try:
            raw = raw.encode("utf-8")
        except UnicodeError:
            fail("INVALID_UTF8")
    if type(raw) is not bytes:
        fail("INVALID_WIRE_TYPE")
    if len(raw) > limit:
        fail("PAYLOAD_TOO_LARGE")
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=_pairs,
                          parse_constant=_constant, parse_float=_float)
    except ContractError:
        raise
    except (ValueError, UnicodeError, RecursionError, OverflowError):
        fail("INVALID_JSON")


def uuid4_string(value):
    if type(value) is not str:
        fail("INVALID_UUID")
    try:
        parsed = UUID(value)
    except (ValueError, AttributeError):
        fail("INVALID_UUID")
    if parsed.version != 4 or str(parsed) != value:
        fail("INVALID_UUID")
    return value


def nonnegative_integer(value):
    if type(value) is not int or value < 0:
        fail("INVALID_INTEGER")
    return value


def bounded_text(value, maximum):
    if type(value) is not str or not value.strip() or len(value) > maximum:
        fail("INVALID_TEXT")
    # Reject unpaired surrogates, including escaped ones in JSON.
    try:
        value.encode("utf-8")
    except UnicodeError:
        fail("INVALID_UTF8")
    return value


@dataclass(frozen=True)
class Telemetry:
    boot_id: str
    sequence: int
    uptime_ms: int
    scenario: str
    signals: tuple
    sample_sha256: str
    canonical_json: str

    def signal_values(self):
        return dict(self.signals)


def parse_telemetry(raw):
    data = load_wire(raw, MAX_TELEMETRY_BYTES)
    exact_keys(data, ("schema_version", "asset_id", "node_id", "boot_id", "sequence",
                      "uptime_ms", "simulated", "scenario", "signals"))
    if data["schema_version"] != "forge.telemetry.v1":
        fail("INVALID_SCHEMA_VERSION")
    if data["asset_id"] != "P-204" or data["node_id"] != "forge-edge-01":
        fail("UNKNOWN_IDENTITY")
    if data["simulated"] is not True:
        fail("SIMULATION_REQUIRED")
    uuid4_string(data["boot_id"])
    nonnegative_integer(data["sequence"])
    nonnegative_integer(data["uptime_ms"])
    if type(data["scenario"]) is not str or data["scenario"] not in SCENARIOS:
        fail("INVALID_SCENARIO")
    exact_keys(data["signals"], SIGNAL_RANGES)
    for key, (lower, upper) in SIGNAL_RANGES.items():
        value = data["signals"][key]
        if key in INTEGER_SIGNALS:
            if type(value) is not int:
                fail("INVALID_SIGNAL_TYPE")
        elif type(value) not in (int, float):
            fail("INVALID_SIGNAL_TYPE")
        # Comparisons avoid overflowing float conversion for huge integers.
        if not lower <= value <= upper:
            fail("SIGNAL_OUT_OF_RANGE")
        if type(value) is float and not math.isfinite(value):
            fail("NONFINITE_JSON_NUMBER")
    canonical = json.dumps(data, sort_keys=True, separators=(",", ":"),
                           ensure_ascii=False, allow_nan=False)
    return Telemetry(data["boot_id"], data["sequence"], data["uptime_ms"], data["scenario"],
                     tuple(sorted(data["signals"].items())),
                     hashlib.sha256(canonical.encode("utf-8")).hexdigest(), canonical)


@dataclass(frozen=True)
class Query:
    request_id: str
    asset_id: str = "P-204"


def parse_query(raw):
    data = load_wire(raw, 1024)
    exact_keys(data, ("schema_version", "request_id", "asset_id"))
    if data["schema_version"] != "forge.query.v1":
        fail("INVALID_SCHEMA_VERSION")
    if data["asset_id"] != "P-204":
        fail("UNKNOWN_IDENTITY")
    return Query(uuid4_string(data["request_id"]))


@dataclass(frozen=True)
class Reasoning:
    summary: str
    signal_explanations: tuple
    recommended_checks: tuple
    uncertainty: str


def parse_reasoning(raw):
    data = load_wire(raw, 8192)
    exact_keys(data, ("schema_version", "summary", "signal_explanations",
                      "recommended_checks", "uncertainty"))
    if data["schema_version"] != "forge.reasoning.v1":
        fail("INVALID_SCHEMA_VERSION")
    summary = bounded_text(data["summary"], 600)
    uncertainty = bounded_text(data["uncertainty"], 400)
    explanations = data["signal_explanations"]
    checks = data["recommended_checks"]
    if type(explanations) is not list or not 1 <= len(explanations) <= 6:
        fail("INVALID_EXPLANATIONS")
    if type(checks) is not list or not 1 <= len(checks) <= 4:
        fail("INVALID_RECOMMENDATIONS")
    entries = []
    seen = set()
    for row in explanations:
        exact_keys(row, ("signal", "explanation"))
        signal = row["signal"]
        if type(signal) is not str or signal not in SIGNAL_RANGES or signal in seen:
            fail("INVALID_SIGNAL_REFERENCE")
        seen.add(signal)
        entries.append((signal, bounded_text(row["explanation"], 200)))
    return Reasoning(summary, tuple(entries), tuple(bounded_text(c, 200) for c in checks), uncertainty)


def parse_model_reasoning(raw):
    """Accept bare JSON or one complete JSON code fence; never extract prose fragments."""
    if type(raw) is str:
        if len(raw.encode("utf-8"))>8192:fail("PAYLOAD_TOO_LARGE")
        stripped=raw.strip()
        if stripped.startswith("```json\n") and stripped.endswith("\n```"):
            raw=stripped[len("```json\n"):-len("\n```")]
        elif stripped.startswith("```\n") and stripped.endswith("\n```"):
            raw=stripped[len("```\n"):-len("\n```")]
    return parse_reasoning(raw)
