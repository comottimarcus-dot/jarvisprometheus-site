"""One explicit industrial query; no retries and no credential echo."""
import asyncio
import json
import os
import re
import subprocess
from uuid import uuid4

TOKEN_PARSER_SOURCE = r"""
import re
import shlex

def parse_token(text):
    values=[]
    for line in text.splitlines():
        key,sep,value=line.strip().partition("=")
        if sep and key=="JARVIS_VOICE_MEMORY_TOKEN":
            parts=shlex.split(value,comments=False,posix=True)
            if len(parts)!=1:raise ValueError("invalid token declaration")
            values.append(parts[0])
    if len(values)!=1 or not re.fullmatch(r"[A-Za-z0-9._~+/=-]{1,512}",values[0]):
        raise ValueError("invalid token")
    return values[0]
"""


def load_token():
    token=os.environ.get("JARVIS_VOICE_MEMORY_TOKEN")
    if token:
        if not re.fullmatch(r"[A-Za-z0-9._~+/=-]{1,512}",token):
            raise SystemExit("CORE_AUTHENTICATION_INVALID")
        return token
    # Core main.py loads this dotenv file; query the same key without exposing it.
    from dotenv import dotenv_values
    try:
        token=dotenv_values("/home/marcus/jarvis-core/.env").get("JARVIS_VOICE_MEMORY_TOKEN")
    except OSError:
        token=None
    if token:
        if not re.fullmatch(r"[A-Za-z0-9._~+/=-]{1,512}",token):
            raise SystemExit("CORE_AUTHENTICATION_INVALID")
        return token
    namespace={}
    exec(TOKEN_PARSER_SOURCE,namespace)
    path="/etc/jarvis/voice-bridge.env"
    try:
        with open(path,encoding="utf-8") as f:
            return namespace["parse_token"](f.read())
    except PermissionError:
        # Sudo reads only the fixed credential file/key; stdout is captured, not displayed.
        reader=TOKEN_PARSER_SOURCE+"\nfrom pathlib import Path\nimport sys\ntry:\n    text=Path('/etc/jarvis/voice-bridge.env').read_text()\nexcept OSError:\n    sys.exit(21)\ntry:\n    token=parse_token(text)\nexcept ValueError:\n    sys.exit(20)\nprint(token)\n"
        try:
            result=subprocess.run(["sudo","--","/usr/bin/python3","-c",reader],
                stdout=subprocess.PIPE,
                text=True,timeout=120,check=False)
        except (OSError,subprocess.TimeoutExpired):
            raise SystemExit("CORE_CREDENTIAL_READ_UNAVAILABLE") from None
        if result.returncode==20:
            raise SystemExit("CORE_TOKEN_DECLARATION_INVALID")
        if result.returncode==21:
            raise SystemExit("CORE_CREDENTIAL_FILE_UNREADABLE")
        token=result.stdout.strip()
        if result.returncode or not re.fullmatch(r"[A-Za-z0-9._~+/=-]{1,512}",token):
            raise SystemExit("CORE_CREDENTIAL_READ_REQUIRES_SUDO — authenticate when sudo prompts")
        return token
    except (OSError,ValueError):
        raise SystemExit("CORE_AUTHENTICATION_NOT_AVAILABLE") from None


async def query():
    from websockets.asyncio.client import connect
    token=load_token()
    request_id=str(uuid4())
    async with connect("ws://127.0.0.1:8765/voice-capability",proxy=None,
        additional_headers={"Authorization":"Bearer "+token},open_timeout=3,max_size=32768) as ws:
        payload={"operation":"forge_check_asset","request_id":request_id,"asset_id":"P-204"}
        language=os.environ.get("FORGE_LANGUAGE")
        if language is not None:
            if language not in ("pt-BR","en"):raise SystemExit("INVALID_LANGUAGE")
            payload["language"]=language
        expected=os.environ.get("FORGE_EXPECTED_SEVERITY")
        if expected is not None:
            if expected not in ("normal","warning","critical"):raise SystemExit("INVALID_EXPECTED_SEVERITY")
            payload["expected_severity"]=expected
        await ws.send(json.dumps(payload))
        data=json.loads(await asyncio.wait_for(ws.recv(),130))
        if data.get("request_id")!=request_id or data.get("operation")!="forge_check_asset":
            raise SystemExit("CORE_RESULT_NOT_CORRELATED")
        print(json.dumps(data,ensure_ascii=False,indent=2))

if __name__=="__main__":asyncio.run(query())
