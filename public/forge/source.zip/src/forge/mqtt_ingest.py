"""TLS-authenticated subscription; never connects to a GPU."""
import argparse
import json
import os
from pathlib import Path
import ssl
import time
from .ingest import TelemetryStore, TOPIC, STATUS_TOPIC


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--config",required=True)
    args=parser.parse_args()
    os.umask(0o077)
    path=Path(args.config)
    if path.stat().st_mode & 0o077: raise SystemExit("CONFIG_MUST_BE_PRIVATE")
    config=json.loads(path.read_text())
    import paho.mqtt.client as mqtt
    store=TelemetryStore(str(path.parent/"replay.sqlite3"))
    client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id="forge-ingest-01",protocol=mqtt.MQTTv311)
    client.username_pw_set("forge-ingest-01",config["reader_password"])
    client.tls_set(ca_certs=config["ca"],cert_reqs=ssl.CERT_REQUIRED,tls_version=ssl.PROTOCOL_TLS_CLIENT)
    client.tls_insecure_set(False)
    client.max_queued_messages_set(10)
    def connect(c,u,flags,reason,props):
        if reason.is_failure: store.transport_lost();return
        c.subscribe([(TOPIC,1),(STATUS_TOPIC,1)])
    def lost(c,u,flags,reason,props):store.transport_lost()
    def message(c,u,m):
        if m.topic==STATUS_TOPIC:
            if not m.retain and m.payload==b"offline":store.transport_lost()
            return
        result=store.receive(m.payload,topic=m.topic,retained=m.retain,authenticated=True)
        print(json.dumps({"event":"ingest",**result}),flush=True)
    client.on_connect=connect;client.on_disconnect=lost;client.on_message=message
    try:
        client.connect(config["host"],18884,keepalive=10);client.loop_start()
        while True:
            print(json.dumps({"event":"snapshot",**store.snapshot()}),flush=True)
            time.sleep(1)
    except KeyboardInterrupt:pass
    finally:
        client.disconnect();client.loop_stop();store.close()

if __name__=="__main__":main()
