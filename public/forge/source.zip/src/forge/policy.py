"""Deterministic demo thresholds; not certified industrial trip limits."""
from dataclasses import dataclass
import math
from .contracts import ContractError, parse_telemetry

POLICY_VERSION = "forge.demo.pump.v1"
TTL_MS = 5000
# Each triggered rule is recorded, including warning rules below a critical result.
RULES = (
    ("temperature_c", "critical", "gte", 90), ("temperature_c", "warning", "gte", 75),
    ("vibration_rms_mm_s", "critical", "gte", 7), ("vibration_rms_mm_s", "warning", "gte", 4),
    ("pressure_bar", "critical", "lt", 4.5), ("pressure_bar", "warning", "lt", 5.8),
    ("motor_current_a", "critical", "gte", 17), ("motor_current_a", "warning", "gte", 14),
    ("rpm", "critical", "lt", 1400), ("rpm", "warning", "lt", 1475),
    ("maintenance_overdue_hours", "critical", "gte", 168),
    ("maintenance_overdue_hours", "warning", "gt", 0),
)

@dataclass(frozen=True)
class RuleFinding:
    rule_id: str
    signal: str
    value: int | float
    severity: str
    comparison: str
    threshold: int | float

@dataclass(frozen=True)
class Assessment:
    availability: str
    severity: str | None
    findings: tuple[RuleFinding, ...] = ()
    sample_sha256: str | None = None
    reason: str | None = None
    policy_version: str = POLICY_VERSION


def assess(raw, *, age_ms, connected=True, latest_message_valid=True):
    """Assess trusted local receipt metadata, not device-provided freshness.

    Ingest authentication, replay handling and clock ownership are subsequent stages.
    This function does not admit compute or authorize recommendations/actuation.
    """
    if type(connected) is not bool or type(latest_message_valid) is not bool:
        raise ContractError("INVALID_RECEIPT_METADATA")
    if age_ms is not None:
        if type(age_ms) not in (int, float) or age_ms < 0:
            raise ContractError("INVALID_AGE")
        if type(age_ms) is float and not math.isfinite(age_ms):
            raise ContractError("INVALID_AGE")
    if not connected:
        return Assessment("offline", None, reason="TRANSPORT_OFFLINE")
    if not latest_message_valid:
        return Assessment("invalid", None, reason="LATEST_MESSAGE_INVALID")
    if raw is None:
        return Assessment("unavailable", None, reason="NO_ACCEPTED_SAMPLE")
    try:
        telemetry = parse_telemetry(raw)
    except ContractError as exc:
        return Assessment("invalid", None, reason=exc.code)
    if age_ms is None:
        raise ContractError("MISSING_RECEIPT_AGE")
    if age_ms > TTL_MS:
        return Assessment("stale", None, sample_sha256=telemetry.sample_sha256, reason="SAMPLE_EXPIRED")
    findings = []
    values = telemetry.signal_values()
    for key, severity, comparison, threshold in RULES:
        value = values[key]
        hit = (value >= threshold if comparison == "gte" else
               value < threshold if comparison == "lt" else value > threshold)
        if hit:
            findings.append(RuleFinding(f"{key}.{severity}", key, value, severity, comparison, threshold))
    severity = ("critical" if any(f.severity == "critical" for f in findings)
                else "warning" if findings else "normal")
    return Assessment("fresh", severity, tuple(findings), telemetry.sample_sha256)
