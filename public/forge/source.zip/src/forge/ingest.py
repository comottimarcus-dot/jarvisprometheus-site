"""Durable replay guards with process-local receipt freshness."""
from dataclasses import asdict
from datetime import datetime, timezone
import sqlite3
import threading
import time
from .contracts import ContractError, parse_telemetry
from .policy import assess

TOPIC = "forge/edge-01/telemetry"
STATUS_TOPIC = "forge/edge-01/status"

class TelemetryStore:
    def __init__(self, database, *, clock=time.monotonic):
        self.clock = clock
        self.lock = threading.RLock()
        self.db = sqlite3.connect(database, check_same_thread=False)
        self.db.executescript("""CREATE TABLE IF NOT EXISTS boots (
            id TEXT PRIMARY KEY, seq INTEGER NOT NULL, uptime INTEGER NOT NULL,
            hash TEXT NOT NULL, retired INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);""")
        self.db.commit()
        self.raw = None
        self.received = None
        self.received_at = None
        self.connected = False
        self.transport_failed = False
        self.valid = True
        self.reason = None

    def close(self):
        with self.lock: self.db.close()

    def transport_lost(self):
        with self.lock:
            self.connected = False
            self.transport_failed = True

    def reject(self, code):
        self.valid = False
        self.reason = code
        return {"accepted": False, "reason": code}

    def receive(self, raw, *, topic=TOPIC, retained=False, authenticated=False):
        with self.lock:
            if authenticated is not True:
                return self.reject("UNAUTHENTICATED_TRANSPORT")
            if topic != TOPIC:
                return self.reject("UNEXPECTED_TOPIC")
            if retained is not False:
                return self.reject("RETAINED_TELEMETRY")
            try:
                t = parse_telemetry(raw)
            except ContractError as exc:
                return self.reject(exc.code)
            if t.sequence > 2**63-1 or t.uptime_ms > 2**63-1:
                return self.reject("COUNTER_TOO_LARGE")
            current = self.db.execute("SELECT value FROM meta WHERE key='active_boot'").fetchone()
            row = self.db.execute("SELECT seq,uptime,hash,retired FROM boots WHERE id=?",(t.boot_id,)).fetchone()
            if row:
                seq, uptime, digest, retired = row
                if retired: return self.reject("RETIRED_BOOT")
                if t.sequence < seq: return self.reject("OLD_SEQUENCE")
                if t.sequence == seq:
                    if digest != t.sample_sha256: return self.reject("CONFLICTING_DUPLICATE")
                    # Do not reset freshness or clear an invalid-latest-message state.
                    return {"accepted": False, "reason": "DUPLICATE_IGNORED"}
                if t.uptime_ms < uptime: return self.reject("UPTIME_REGRESSION")
            elif self.db.execute("SELECT count(*) FROM boots").fetchone()[0] >= 1024:
                return self.reject("BOOT_HISTORY_LIMIT")
            try:
                with self.db:
                    if current and current[0] != t.boot_id:
                        self.db.execute("UPDATE boots SET retired=1 WHERE id=?",(current[0],))
                    self.db.execute("INSERT INTO boots VALUES (?,?,?,?,0) ON CONFLICT(id) DO UPDATE SET seq=excluded.seq,uptime=excluded.uptime,hash=excluded.hash",(t.boot_id,t.sequence,t.uptime_ms,t.sample_sha256))
                    self.db.execute("INSERT INTO meta VALUES ('active_boot',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(t.boot_id,))
            except sqlite3.Error:
                return self.reject("REPLAY_STATE_WRITE_FAILED")
            self.raw=t.canonical_json
            self.received=self.clock()
            self.received_at=datetime.now(timezone.utc).isoformat()
            self.connected=True;self.valid=True;self.reason=None
            return {"accepted": True, "sample_sha256":t.sample_sha256}

    def snapshot(self):
        with self.lock:
            age=None if self.received is None else max(0,(self.clock()-self.received)*1000)
            result=asdict(assess(self.raw,age_ms=age,connected=self.connected,latest_message_valid=self.valid))
            # Process startup has no trusted current sample, even with persisted counters.
            if self.raw is None and self.valid and not self.connected and not self.transport_failed:
                result["availability"]="unavailable";result["reason"]="NO_ACCEPTED_SAMPLE"
            result.update(received_at=self.received_at,age_ms=age,latest_error=self.reason,
                          mode="local_ingest_rules_only",amd_calls=0,actuator_calls=0)
            return result
