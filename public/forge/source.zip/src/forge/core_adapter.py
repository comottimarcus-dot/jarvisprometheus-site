"""Called inside Core after its existing loopback/bearer authentication."""
import asyncio
from pathlib import Path
import threading
import json
import time
from .contracts import exact_keys,parse_query
from .core_feed import CoreFeed
from .industrial_execution import IndustrialService

ROOT=Path(__file__).resolve().parents[2]
_service=None
_init_lock=threading.Lock()

def _execute(cognitive,data):
    global _service
    with _init_lock:
        if _service is None:
            feed=CoreFeed(ROOT)
            _service=IndustrialService(feed.store,ROOT)
            # Wait for initial subscription only; never repeat an execution request.
            deadline=time.monotonic()+3
            while feed.store.snapshot()["availability"]!="fresh" and time.monotonic()<deadline:
                time.sleep(0.05)
    if data["operation"]=="forge_asset_status":return _service.status(data)
    return _service.execute(data,cognitive.runtime.execution)

async def dispatch_forge(cognitive,data):
    # Validate before publishing correlated Core events.
    fields=("operation","request_id","asset_id")
    exact_keys(data,fields+tuple(k for k in ("expected_severity","language") if k in data))
    if data["operation"] not in ("forge_check_asset","forge_asset_status"):raise ValueError("unsupported FORGE operation")
    query=parse_query(json.dumps({"schema_version":"forge.query.v1","request_id":data["request_id"],"asset_id":data["asset_id"]}))
    from cognition.events.cognitive_event import CognitiveEvent
    from cognition.events.event_types import EventType
    from cognition.timeline.capability_trace import execution_summary
    thought_id="forge-"+query.request_id
    async def publish(kind,payload):
        await cognitive.event_bus.publish(CognitiveEvent(type=kind,payload=payload,
            thought_id=thought_id,metadata={"source":"forge-act3","execution_only":True}))
    local=data["operation"]=="forge_asset_status"
    capability="telemetry" if local else "reasoning"
    await publish(EventType.CAPABILITY_REQUESTED,{"capability":capability})
    result=await asyncio.to_thread(_execute,cognitive,data)
    execution=result.get("execution") or {}
    confirmed=result.get("ok") is True and result.get("executed_now") is True
    row={"capability":capability,"provider":"forge-local" if local else "amd-vllm","success":result.get("current_state_claim") is True if local else confirmed,
         "metadata":{key:execution.get(key) for key in ("executor_id","route_key","model","node","gpu","backend","hardware_evidence","inventory_observed_at")}}
    await publish(EventType.CAPABILITY_COMPLETED,{"execution_results":[row],"execution_mode":"explicit_forge_query"})
    result["thought_id"]=thought_id
    result["executions"]=execution_summary({},[row])
    return result
