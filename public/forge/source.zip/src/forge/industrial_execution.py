"""Industrial operation over an already-owned X6 runtime; paid calls fail closed."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import threading
import time
from .contracts import ContractError,exact_keys,parse_query,parse_model_reasoning,parse_telemetry

from .governance import checks_for,review,metadata

class IndustrialService:
    def __init__(self, store, root, *, ingress_factory=None, environ=None):
        self.store=store;self.root=Path(root);self.lock=threading.Lock()
        self.ingress_factory=ingress_factory;self.environ=environ
        self.db=sqlite3.connect(str(self.root/".runtime/compute.sqlite3"),check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,allocation TEXT NOT NULL)")
        self.db.commit()

    def close(self):self.db.close()

    def blocked(self,request_id,reason,snapshot=None,language="pt-BR"):
        return {"schema_version":"forge.result.v1","asset_id":"P-204","simulated":True,"ok":False,"operation":"forge_check_asset","request_id":request_id,
            "executed_now":False,"language":language,"response":("FORGE query not confirmed: " if language=="en" else "Consulta FORGE não confirmada: ")+reason,
            "reason":reason,"snapshot":snapshot,
            "governance":{"mode":"recommendation_only","gate_result":"blocked",
                "physical_actuation_authorized":False,"physical_actuation_performed":False}}

    def allocation(self):
        import os
        env=self.environ if self.environ is not None else os.environ
        path=self.root/".runtime/compute-allocation.json"
        if not path.is_file():raise ContractError("FORGE_COMPUTE_NOT_AUTHORIZED")
        if path.stat().st_mode & 0o077:raise ContractError("ALLOCATION_NOT_PRIVATE")
        if path.stat().st_size>2048:raise ContractError("INVALID_ALLOCATION")
        try:
            d=json.loads(path.read_text())
            fields=("campaign","authorization_id","endpoint_sha256","max_requests","expires_at")
            if d.get("campaign")=="academy":
                exact_keys(d,fields+("purpose",))
                if d["purpose"]!="forge_user_authorized":raise ValueError()
            else:
                exact_keys(d,fields)
                if d["campaign"]!="act3":raise ValueError()
            a=d["authorization_id"]
            if type(a) is not str or not 1<=len(a)<=100 or not a.isascii() or not all(c.isalnum() or c in "-_" for c in a):raise ValueError()
            if d["max_requests"] is not None and (type(d["max_requests"]) is not int or d["max_requests"]<1):raise ValueError()
            expiry=datetime.fromisoformat(d["expires_at"])
            if expiry.tzinfo is None or expiry<=datetime.now(timezone.utc):raise ValueError()
            origin=env.get("JARVIS_MI300X_BASE_URL","").strip().rstrip("/")
            if env.get("JARVIS_MI300X_ENABLED")!="1" or not origin or not env.get("JARVIS_MI300X_MODEL"):raise ValueError()
            if d["endpoint_sha256"]!=hashlib.sha256(origin.encode()).hexdigest():raise ValueError()
            return d
        except (OSError,ValueError,TypeError,KeyError):raise ContractError("ALLOCATION_INVALID_OR_EXPIRED") from None

    def execute(self, data, runtime):
        fields=("operation","request_id","asset_id")
        expected=data.get("expected_severity")
        exact_keys(data,fields+tuple(k for k in ("expected_severity","language") if k in data))
        language=data.get("language","pt-BR")
        if language not in ("pt-BR","en"):raise ContractError("INVALID_LANGUAGE")
        if "expected_severity" in data and expected not in ("normal","warning","critical"):
            raise ContractError("INVALID_EXPECTED_SEVERITY")
        if data["operation"]!="forge_check_asset":raise ContractError("INVALID_OPERATION")
        query=parse_query(json.dumps({"schema_version":"forge.query.v1","request_id":data["request_id"],"asset_id":data["asset_id"]}))
        if not self.lock.acquire(blocking=False):return self.blocked(query.request_id,"FORGE_BUSY",language=language)
        attempted=False;physical_confirmed=False;output={}
        try:
            # Freeze telemetry and receipt metadata under the ingest lock.
            with self.store.lock:
                snap=self.store.snapshot()
                raw=self.store.raw
            if snap["availability"]!="fresh":return self.blocked(query.request_id,"TELEMETRY_"+snap["availability"].upper(),snap,language)
            if expected is not None and snap["severity"]!=expected:
                return self.blocked(query.request_id,"SCENARIO_MISMATCH",snap,language)
            telemetry=parse_telemetry(raw)
            try:d=self.allocation()
            except ContractError as e:return self.blocked(query.request_id,e.code,snap,language)
            if self.db.execute("SELECT 1 FROM requests WHERE id=?",(query.request_id,)).fetchone():return self.blocked(query.request_id,"REQUEST_ALREADY_ADMITTED",snap,language)
            count=self.db.execute("SELECT count(*) FROM requests WHERE allocation=?",(d["authorization_id"],)).fetchone()[0]
            if d["max_requests"] is not None and count>=d["max_requests"]:return self.blocked(query.request_id,"FORGE_REQUEST_BUDGET_EXHAUSTED",snap,language)
            with self.db:self.db.execute("INSERT INTO requests VALUES (?,?)",(query.request_id,d["authorization_id"]))
            context={"asset_id":"P-204","simulated":True,"policy_version":snap["policy_version"],
                     "severity":snap["severity"],"signals":telemetry.signal_values(),"triggered_rules":snap["findings"]}
            prompt=("Explain this simulated pump assessment in "+("English" if language=="en" else "Brazilian Portuguese")+". Trusted rules already determine severity. "
                "No physical actuation is authorized. Do not invent measurements, sensors, manuals or causes. "
                "Recommend only human inspection. Return ONLY a JSON object with exact keys: "
                "schema_version (forge.reasoning.v1), summary (1..600 chars), signal_explanations "
                "(1..6 objects each with signal and explanation <=200 chars, using unique supplied signal keys), "
                "recommended_checks (1..4 strings <=200 chars), uncertainty (1..400 chars). "
                "Mention simulation and uncertainty. No markdown, extra fields or commands. "
                "recommended_checks must be unique exact strings selected from: "+json.dumps(checks_for(language),ensure_ascii=False)+
                ". Context: "+json.dumps(context))
            if self.ingress_factory is None:
                from execution.x6_ingress import X6Ingress
                ingress=X6Ingress(runtime)
            else:ingress=self.ingress_factory(runtime)
            start=time.monotonic();attempted=True
            outcome=ingress.execute_reasoning_prompt(prompt,metadata={"source":"forge-act3","request_id":query.request_id,"thought_id":"forge-"+query.request_id,
                "asset_id":"P-204","sample_sha256":telemetry.sample_sha256,"policy_version":snap["policy_version"],"allocation_id":d["authorization_id"],"credit_campaign":d["campaign"]})
            output=dict(outcome.output) if outcome.succeeded else {}
            import os
            env=self.environ if self.environ is not None else os.environ
            if (output.get("physical_execution") is not True or output.get("executor_id")!="amd-mi300x-vllm"
                or output.get("route_key")!="amd-mi300x-reasoning" or output.get("finish_reason")!="stop"
                or output.get("model")!=env.get("JARVIS_MI300X_MODEL")):
                raise ContractError("AMD_EXECUTION_NOT_CONFIRMED")
            physical_confirmed=True
            reasoning=parse_model_reasoning(output.get("content"))
            latest=self.store.snapshot()
            decision=review(reasoning,snap,latest,language)
            historical=decision.historical
            response=decision.response
            return {"schema_version":"forge.result.v1","asset_id":"P-204","simulated":True,"availability":latest["availability"],
                "language":language,"historical":historical,"current_state_claim":not historical,"ok":True,"operation":"forge_check_asset","request_id":query.request_id,"executed_now":True,
                "response":response,"scope":"historical_sample" if historical else "simulated_industrial_recommendation",
                "sample_reference":{"boot_id":telemetry.boot_id,"sequence":telemetry.sequence,"sample_sha256":telemetry.sample_sha256,
                  "received_at":snap["received_at"],"age_at_admission_ms":snap["age_ms"]},
                "severity":snap["severity"],"policy_version":snap["policy_version"],"triggered_rules":snap["findings"],
                "funding":{"credit_campaign":d["campaign"],"project":"forge-act3","allocation_id":d["authorization_id"],"operator_declared":True},
                "reasoning":{"schema_version":"forge.reviewed-reasoning.v1","recommended_checks":list(decision.checks),"model_prose_published":False},"elapsed_seconds":round(time.monotonic()-start,3),
                "execution":{k:output.get(k) for k in ("executor_id","route_key","model","node","gpu","backend","completion_id","usage","hardware_evidence","inventory_observed_at")},
                "governance":metadata(decision),
                "instruction":"Report only this result; no automatic retry, no pump shutdown claim. Historical scope is not current state."}
        except Exception as exc:
            reason=exc.code if isinstance(exc,ContractError) else "FORGE_EXECUTION_UNCONFIRMED"
            result=self.blocked(query.request_id,reason,language=language)
            if language=="en":result["response"]="FORGE query not confirmed: "+reason
            result["language"]=language
            result["execution_attempted"]=attempted
            result["amd_completion_confirmed"]=physical_confirmed
            if physical_confirmed:
                result["execution"]={k:output.get(k) for k in ("executor_id","route_key","model","node","gpu","backend","completion_id","usage","hardware_evidence","inventory_observed_at")}
                result["sample_reference"]={"boot_id":telemetry.boot_id,"sequence":telemetry.sequence,"sample_sha256":telemetry.sample_sha256}
                result["severity"]=snap["severity"]
                result["funding"]={"credit_campaign":d["campaign"],"project":"forge-act3","allocation_id":d["authorization_id"],"operator_declared":True}
                # Private audit only: model output is untrusted and never voice content.
                audit=self.root/".runtime"/("model-rejected-"+query.request_id+".json")
                content=output.get("content")
                body={"request_id":query.request_id,"reason":reason,"untrusted_model_content":content[:8192] if isinstance(content,str) else None}
                try:
                    import os
                    fd=os.open(audit,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                    with os.fdopen(fd,"w") as f:json.dump(body,f,ensure_ascii=True)
                    result["private_diagnostic_saved"]=True
                except OSError:result["private_diagnostic_saved"]=False
            return result
        finally:self.lock.release()

    def status(self,data):
        fields=("operation","request_id","asset_id")
        exact_keys(data,fields+(("language",) if "language" in data else ()))
        if data["operation"]!="forge_asset_status":raise ContractError("INVALID_OPERATION")
        query=parse_query(json.dumps({"schema_version":"forge.query.v1","request_id":data["request_id"],"asset_id":data["asset_id"]}))
        language=data.get("language","pt-BR")
        if language not in ("pt-BR","en"):raise ContractError("INVALID_LANGUAGE")
        snap=self.store.snapshot()
        fresh=snap["availability"]=="fresh"
        if language=="en":
            response=(f'Simulated pump P-204 telemetry is {snap["severity"]}, based on fresh local telemetry. No AMD inference was requested.' if fresh else f'Current pump P-204 state is not confirmed. Telemetry is {snap["availability"]}. No AMD inference was requested.')+' No physical action was authorized or performed.'
        else:
            response=(f'A telemetria simulada da bomba P-204 está em {snap["severity"]}, com amostra local fresca. Nenhuma inferência AMD foi solicitada.' if fresh else f'O estado atual da bomba P-204 não está confirmado. Telemetria {snap["availability"]}. Nenhuma inferência AMD foi solicitada.')+' Nenhuma ação física foi autorizada ou executada.'
        return {"schema_version":"forge.result.v1","operation":"forge_asset_status","request_id":query.request_id,"asset_id":"P-204","simulated":True,"ok":True,"executed_now":False,"language":language,"response":response,"snapshot":snap,"current_state_claim":fresh,"scope":"local_telemetry_status","governance":{"mode":"recommendation_only","gate_result":"local_status_only","physical_actuation_authorized":False,"physical_actuation_performed":False},"instruction":"Speak only the returned response. This is local telemetry, not AMD execution. Never retry automatically or invent current state."}
