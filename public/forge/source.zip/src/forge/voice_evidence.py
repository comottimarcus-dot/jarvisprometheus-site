"""Normalize only known bridge logger envelopes, retaining actual correlation IDs."""
import re
from uuid import UUID

LINE=re.compile(r'^(?:INFO:prometheus_voice\.xiaozhi_bridge:)?(FORGE (?:Core result|playback started|playback submitted completely):[^\r\n]*)$')
ID=re.compile(r'\brequest_id=([0-9a-f-]{36})(?=\s|;|$)')

def normalize_voice_log(message):
    if not isinstance(message,str) or len(message)>4000:return None
    line=LINE.fullmatch(message)
    if not line:return None
    body=line.group(1)
    found=ID.search(body)
    if not found:return None
    try:
        if str(UUID(found.group(1)))!=found.group(1):return None
    except ValueError:return None
    return body
