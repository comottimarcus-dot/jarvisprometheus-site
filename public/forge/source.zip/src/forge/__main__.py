"""Local fixture validation. No network, GPU or device calls."""
from dataclasses import asdict
import json
from pathlib import Path
from .policy import assess


def main():
    fixtures = Path(__file__).resolve().parents[2] / "fixtures"
    results = []
    for scenario in ("normal", "warning", "critical"):
        raw = (fixtures / f"{scenario}.json").read_bytes()
        assessment = assess(raw, age_ms=0)
        if assessment.severity != scenario or assessment.availability != "fresh":
            raise SystemExit("FIXTURE_VALIDATION_FAILED")
        results.append({"fixture": scenario, **asdict(assessment)})
    print(json.dumps({"stage":"FORGE-01", "validation":"pass", "mode":"local_fixture_rules_only",
        "amd_calls":0, "actuator_calls":0, "results":results}, indent=2))

if __name__ == "__main__":
    main()
