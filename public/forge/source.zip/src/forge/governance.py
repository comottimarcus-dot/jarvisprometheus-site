"""Bounded human inspection recommendations; model prose never becomes voice text."""
from dataclasses import dataclass
from .contracts import ContractError

GATE_VERSION='forge.gate.v1'
ALLOWED_CHECKS=(
    'Solicitar inspeção do rolamento por um técnico.',
    'Solicitar verificação da pressão por um técnico.',
    'Solicitar revisão do histórico de manutenção por um técnico.',
    'Solicitar conferência das medições por um técnico.',
)

@dataclass(frozen=True)
class GateDecision:
    historical: bool
    checks: tuple[str,...]
    response: str


def review(reasoning, snapshot, latest, language="pt-BR"):
    if snapshot.get('availability')!='fresh' or snapshot.get('severity') not in ('normal','warning','critical'):
        raise ContractError('GOVERNANCE_INVALID_ASSESSMENT')
    checks=reasoning.recommended_checks
    if len(set(checks))!=len(checks) or any(c not in checks_for(language) for c in checks):
        raise ContractError('GOVERNANCE_RECOMMENDATION_REJECTED')
    historical=(latest.get('availability')!='fresh' or latest.get('sample_sha256')!=snapshot.get('sample_sha256'))
    severity=snapshot['severity']
    if historical:
        response=f'Análise histórica de uma amostra simulada da bomba P-204, classificada como {severity}. O estado atual não está confirmado. Recomendações atuais bloqueadas.'
        approved=()
    else:
        response=f'Telemetria simulada da bomba P-204 classificada como {severity} pelas regras locais. A causa não está comprovada. Recomendações para revisão humana: '+ '; '.join(checks)
        approved=checks
    if language=='en':
        if historical:
            response=f'Historical analysis of a simulated sample from pump P-204, classified as {severity}. Current state is not confirmed. Current recommendations are blocked.'
        else:
            response=f'Simulated telemetry from pump P-204 is classified as {severity} by local rules. The cause is not established. Recommendations for human review: '+ '; '.join(checks)
        response+=' No physical action was authorized or performed.'
    else:
        response+=' Nenhuma ação física foi autorizada ou executada.' 
    return GateDecision(historical,approved,response)


def metadata(decision):
    return {'policy_version':GATE_VERSION,'mode':'recommendation_only',
            'gate_result':'blocked' if decision.historical else 'recommendation_allowed',
            'human_review_required':True,'physical_actuation_authorized':False,
            'physical_actuation_performed':False,'model_prose_published':False}

ALLOWED_CHECKS_EN=(
    'Request bearing inspection by a technician.',
    'Request pressure verification by a technician.',
    'Request maintenance history review by a technician.',
    'Request measurement verification by a technician.',
)

def checks_for(language):
    return ALLOWED_CHECKS_EN if language=='en' else ALLOWED_CHECKS
