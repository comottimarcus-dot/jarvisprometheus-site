"""Evidence assessment; backend success never certifies acoustic delivery."""
from uuid import UUID
from .governance import checks_for,GATE_VERSION


def assess_run(data, expected_severity):
    execution=data.get('execution') or {}
    gate=data.get('governance') or {}
    sample=data.get('sample_reference') or {}
    reasoning=data.get('reasoning') or {}
    historical=data.get('historical') is True
    try:request_valid=str(UUID(data.get('request_id','')))==data.get('request_id')
    except (ValueError,TypeError,AttributeError):request_valid=False
    completion=execution.get('completion_id')
    checks={
        'contract':data.get('schema_version')=='forge.result.v1' and data.get('operation')=='forge_check_asset' and data.get('asset_id')=='P-204' and data.get('simulated') is True and request_valid,
        'successful_execution':data.get('ok') is True and data.get('executed_now') is True,
        'amd_route':execution.get('executor_id')=='amd-mi300x-vllm' and execution.get('route_key')=='amd-mi300x-reasoning',
        'completion_reference':isinstance(completion,str) and bool(completion) and not completion.upper().startswith(('MOCK','TEST')),
        'model_reference':isinstance(execution.get('model'),str) and bool(execution.get('model')),
        'sample_reference':isinstance(sample.get('sample_sha256'),str) and len(sample['sample_sha256'])==64 and all(c in '0123456789abcdef' for c in sample['sample_sha256']),
        'severity':data.get('severity')==expected_severity,
        'gate':gate.get('policy_version')==GATE_VERSION and gate.get('human_review_required') is True and gate.get('model_prose_published') is False,
        'no_actuation':gate.get('physical_actuation_authorized') is False and gate.get('physical_actuation_performed') is False,
        'recommendations':isinstance(reasoning.get('recommended_checks'),list) and all(c in checks_for(data.get("language","pt-BR")) for c in reasoning.get('recommended_checks',[])),
        'scope':(data.get('scope')=='historical_sample' and data.get('current_state_claim') is False and gate.get('gate_result')=='blocked' and reasoning.get('recommended_checks')==[]) if historical else (data.get('historical') is False and data.get('scope')=='simulated_industrial_recommendation' and data.get('current_state_claim') is True and gate.get('gate_result')=='recommendation_allowed' and bool(reasoning.get('recommended_checks'))),
    }
    return {'checks':checks,'backend_evidence_pass':all(checks.values()),'scope':'historical_sample' if historical else 'current_sample',
            'voice_input_verified':False,'acoustic_return_verified':False,'full_golden_run_complete':False,
            'limitation':'Backend evidence uses existing executor assertions; voice and acoustic evidence require separate correlated recording.'}
