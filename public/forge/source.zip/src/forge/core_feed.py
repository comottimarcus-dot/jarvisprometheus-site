"""Independent subscriber in Core; shares broker, not another process's freshness."""
import json
from pathlib import Path
import ssl
from .ingest import TelemetryStore, TOPIC, STATUS_TOPIC

class CoreFeed:
    def __init__(self, root):
        import paho.mqtt.client as mqtt
        path=Path(root)/".runtime/client.json"
        if path.stat().st_mode & 0o077:raise ValueError("CONFIG_NOT_PRIVATE")
        cfg=json.loads(path.read_text())
        self.store=TelemetryStore(str(path.parent/"core-replay.sqlite3"))
        client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id="forge-core-query",protocol=mqtt.MQTTv311)
        client.username_pw_set("forge-ingest-01",cfg["reader_password"])
        client.tls_set(ca_certs=cfg["ca"],cert_reqs=ssl.CERT_REQUIRED,tls_version=ssl.PROTOCOL_TLS_CLIENT)
        client.tls_insecure_set(False)
        def connect(c,u,f,r,props):
            if r.is_failure:self.store.transport_lost()
            else:c.subscribe([(TOPIC,1),(STATUS_TOPIC,1)])
        def lost(c,u,f,r,props):self.store.transport_lost()
        def message(c,u,m):
            if m.topic==STATUS_TOPIC:
                if not m.retain and m.payload==b"offline":self.store.transport_lost()
            else:self.store.receive(m.payload,topic=m.topic,retained=m.retain,authenticated=True)
        client.on_connect=connect;client.on_disconnect=lost;client.on_message=message
        self.client=client
        client.connect_async(cfg["host"],18884,keepalive=10);client.loop_start()
