# PROMETHEUS FORGE

Voice-led review of simulated industrial telemetry, with governed AMD execution.

A physical ESP32-C3 edge node emulates pump P-204 and publishes simulated signals over authenticated TLS MQTT. The Core determines severity with explicit local rules. A spoken status request reads local telemetry without GPU inference. An explicit analysis request invokes Qwen/Qwen3-32B through the existing PROMETHEUS X6 runtime, dispatcher and AMD executor, then passes a constrained recommendation gate.

The existing Xiaozhi/AssemblyAI voice transport carries the request and response. Firmware neither contacts vLLM nor holds cloud credentials nor chooses a GPU.

## Verified on 13 October 2026

- NORMAL, WARNING and CRITICAL telemetry reached the Core with fresh local assessments.
- WARNING and CRITICAL backend runs passed on one AMD Instinct MI300X VF. Recorded service intervals were 6.128 s and 8.466 s, respectively; these are two individual observations, not a latency benchmark.
- The voice journal contains three correlated requests: local status, analysis and a second analysis. English voice-session events were also captured, without inventing missing request IDs for those events.
- The operator confirmed hearing the complete final English analysis response on the Xiaozhi. No audio/video recording or firmware playback-completion ACK is attached.
- The final 66-test local suite passed. Earlier bridge regression tests covered memory, interruption, recovery, gain and the existing AMD tools.

## Evidence boundaries

All telemetry is explicitly simulated. Thresholds are demo policy, not certified industrial trip limits. Local rules establish severity; the model reviews the supplied public signal context. Free model prose is not published. Only allowlisted human-inspection checks can be accepted, and no physical actuation is authorized or performed.

Continuous 1 Hz telemetry changes the admitted sample hash during typical inference. Verified AMD responses therefore have historical scope, and current recommendations are suppressed. A historical response must not be presented as current machine state.

Hardware identity is an operator-verified deployment inventory with an eight-hour validity window, not a physical GPU measurement for every request. Autonomous GPU discovery, physical failover and eight-GPU execution are not demonstrated.

The Core and voice architecture existed before FORGE. The included baseline records source hashes and repository state; it is not a full preexisting source snapshot or an eligibility certification. FORGE adds separate industrial contracts, edge/ingest code, gates, capture tools and small reviewed integration changes. This package is a reviewable project delta and evidence bundle; it requires the existing Core and voice repositories.

Academy credit was used with the operator's explicit authorization. ACT III credit had not been released. The credit origin is preserved in the execution evidence. Request-count restrictions were removed at the operator's request; duplicate admission protection and absence of automatic execution retries remain.

## Included material

- `DEMO_EN.md`: English narration, spoken commands and recording plan.
- `EVIDENCE_REPORT_EN.md`: claims, exact identifiers, timing and limits.
- `EVIDENCE_MATRIX.csv`: concise claim-to-artifact mapping.
- `OPERATOR_RUNBOOK_EN.md`: existing-service checks and English capture commands.
- `evidence/`: original successful and failed captures, listening declaration, tests and deployment inventory.
- `provenance/`: baseline records, installed integration hash checks and current snapshot manifest.
- `source/`: public FORGE source, fixtures, tests, scripts, firmware source and guarded integration candidates.
- `SHA256SUMS`: hashes for every included payload file.

Original evidence is immutable and may contain Portuguese test responses. English prose in this package explains those artifacts; it does not rewrite them as English executions. A final English demo recording is still required before submission.
